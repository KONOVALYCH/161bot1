"""Set or reset the password of the web admin panel.

    .venv\\Scripts\\python set_web_password.py           # writes the hash into .env
    .venv\\Scripts\\python set_web_password.py --print   # only prints the hash (for cloud variables)
"""

import sys

from getpass import getpass
from pathlib import Path

from dotenv import set_key

from web_admin import hash_password


def main():
    path = Path(__file__).resolve().parent / '.env'
    while True:
        first = getpass('Новый пароль (не короче 10 символов): ')
        if len(first) < 10:
            print('Пароль слишком короткий.')
        elif first != getpass('Повторите пароль: '):
            print('Пароли не совпали.')
        else:
            break
    hashed = hash_password(first)
    if '--print' in sys.argv:
        print('\nЗначение для переменной WEB_PASSWORD_HASH (скопируйте целиком):\n')
        print(hashed)
        return
    set_key(path, 'WEB_PASSWORD_HASH', hashed)
    print('Готово. Перезапустите бота. Логин: admin')


if __name__ == '__main__':
    main()
