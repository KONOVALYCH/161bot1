"""Serve appeal-letter templates straight from templates/*.docx on disk.

To change what a document says: open the matching .docx in templates/ with
Microsoft Word or LibreOffice, edit the text, and save it under the SAME
filename. The bot re-reads the file from disk every time someone requests
it — no restart, no code change needed.

To restore a template to its original wording, run generate_templates.py
again (it overwrites just that file, or all of them).
"""

import os
import shutil
from pathlib import Path

DEFAULT_TEMPLATES_DIR = Path(__file__).resolve().parent / 'templates'
TEMPLATES_DIR = DEFAULT_TEMPLATES_DIR  # kept for old imports; use get_templates_dir()


def data_dir():
    """Persistent folder for cloud hosting (e.g. Amvera mounts /data). None = work next to the code."""
    value = os.environ.get('DATA_DIR', '').strip()
    if not value and os.environ.get('AMVERA') == '1':
        value = '/data'  # Amvera sets AMVERA=1 and mounts the only persistent folder here
    return Path(value) if value else None


def get_templates_dir():
    folder = data_dir()
    return folder / 'templates' if folder else DEFAULT_TEMPLATES_DIR


def seed_templates():
    """With DATA_DIR set, copy templates that are missing in the persistent folder.

    Files already there (e.g. replaced from the web admin) are never overwritten,
    so redeploying the code does not undo edits."""
    target = get_templates_dir()
    if target == DEFAULT_TEMPLATES_DIR:
        return
    target.mkdir(parents=True, exist_ok=True)
    for source in DEFAULT_TEMPLATES_DIR.glob('*.docx'):
        if not (target / source.name).exists():
            shutil.copy2(source, target / source.name)

BANK_FILES = {
    'return': 'bank_return.docx',
    'justification': 'bank_justification.docx',
    'complaint': 'bank_complaint.docx',
}
BANK_DOWNLOAD_NAMES = {
    'return': 'Заявление на возврат.docx',
    'justification': 'Обоснование операции.docx',
    'complaint': 'Досудебная претензия.docx',
}
CBR_FILES = {
    'exclude': 'cbr_exclude.docx',
    'complaint': 'cbr_complaint.docx',
}
CBR_DOWNLOAD_NAMES = {
    'exclude': 'Исключение из базы данных ЦБ.docx',
    'complaint': 'Жалоба на бездействие банка.docx',
}
MVD_FILE = 'mvd_request.docx'
MVD_DOWNLOAD_NAME = 'Запрос в МВД.docx'


class TemplateMissing(Exception):
    """Raised when the expected .docx file isn't in templates/ (deleted, renamed, or never generated)."""


def _resolve(disk_filename, download_name):
    path = get_templates_dir() / disk_filename
    if not path.is_file():
        raise TemplateMissing(
            f'{disk_filename} not found in templates/. Run generate_templates.py to restore it, '
            'or check whether it was accidentally renamed or deleted.'
        )
    return download_name, path


def bank_document(doc_key, bank_slug):
    # bank_slug is currently unused for content (one shared template per doc type across all banks)
    # but is kept in the signature so bot.py's routing and click-analytics stay unchanged.
    if doc_key not in BANK_FILES:
        raise ValueError(f'Unknown bank document type: {doc_key}')
    return _resolve(BANK_FILES[doc_key], BANK_DOWNLOAD_NAMES[doc_key])


def cbr_document(doc_key):
    if doc_key not in CBR_FILES:
        raise ValueError(f'Unknown CBR document type: {doc_key}')
    return _resolve(CBR_FILES[doc_key], CBR_DOWNLOAD_NAMES[doc_key])


def mvd_document():
    return _resolve(MVD_FILE, MVD_DOWNLOAD_NAME)
