"""(Re)generate the default appeal-letter templates in templates/*.docx.

Run this once to create the starting templates, or again any time you want to
reset a template back to the original wording:

    .venv\\Scripts\\python generate_templates.py

Editing a template afterwards does NOT require running this script again —
just open the .docx in Word/LibreOffice, change the text, and save. The bot
reads the file fresh from disk every time someone requests it.

IMPORTANT: keep the six filenames exactly as they are (bank_return.docx,
bank_justification.docx, bank_complaint.docx, cbr_exclude.docx,
cbr_complaint.docx, mvd_request.docx) — the bot looks them up by name.
Do not rename or delete them; if a file is missing, that button in the bot
will not work until the file is restored.
"""

import io
from pathlib import Path

from docx import Document
from docx.shared import Pt

TEMPLATES_DIR = Path(__file__).resolve().parent / 'templates'

FOOTER = (
    'Это образец. Заполните поля своими данными (наименование банка, ФИО, номер договора/счёта, '
    'даты, суммы) перед отправкой.'
)


def _build(title, fields, body_paragraphs, footer=FOOTER):
    doc = Document()
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(12)

    heading = doc.add_paragraph()
    run = heading.add_run(title)
    run.bold = True
    run.font.size = Pt(14)
    heading.alignment = 1  # center

    doc.add_paragraph()
    for label, value in fields:
        doc.add_paragraph(f'{label}: {value}')

    doc.add_paragraph()
    for paragraph in body_paragraphs:
        doc.add_paragraph(paragraph)

    doc.add_paragraph()
    doc.add_paragraph('Дата: __.__.____')
    doc.add_paragraph('Подпись: _____________')

    if footer:
        doc.add_paragraph()
        note = doc.add_paragraph()
        note_run = note.add_run(footer)
        note_run.italic = True
        note_run.font.size = Pt(9)
    return doc


DEFAULTS = {
    'bank_return.docx': dict(
        title='Заявление о возврате денежных средств',
        fields=[('Кому', '______________________ (наименование банка)'),
                ('От', '[ваше ФИО, контактный телефон]')],
        body=[
            'Прошу вернуть денежные средства в размере ____ рублей, удержанные или заблокированные '
            'по операции от __.__.____ (номер операции/договора ____), на основании статьи 8 '
            'Федерального закона № 161-ФЗ «О национальной платежной системе».',
            'Прошу рассмотреть заявление и сообщить о принятом решении в письменном виде в '
            'установленный законом срок.',
        ],
    ),
    'bank_justification.docx': dict(
        title='Пояснение по операции',
        fields=[('Кому', '______________________ (наименование банка)'),
                ('От', '[ваше ФИО, контактный телефон]')],
        body=[
            'В связи с запросом банка от __.__.____ прошу принять пояснения по операции от '
            '__.__.____ на сумму ____ рублей.',
            'Источник денежных средств: ______.',
            'Экономический смысл операции и связь с контрагентом: ______.',
            'Прилагаю подтверждающие документы: ______ (договор, переписка, чеки — по обстоятельствам).',
        ],
    ),
    'bank_complaint.docx': dict(
        title='Досудебная претензия',
        fields=[('Кому', '______________________ (наименование банка)'),
                ('От', '[ваше ФИО, контактный телефон]')],
        body=[
            'Настоящим уведомляю о нарушении моих прав как потребителя финансовых услуг в связи с '
            '[указать нарушение — например, необоснованным ограничением операций или отказом в '
            'возврате средств] от __.__.____.',
            'В соответствии со статьёй 8 Федерального закона № 161-ФЗ «О национальной платежной '
            'системе» и Законом РФ № 2300-1 «О защите прав потребителей» прошу устранить нарушение '
            'и предоставить письменный ответ в течение 10 рабочих дней с момента получения настоящей '
            'претензии.',
            'В случае отказа или отсутствия ответа в указанный срок оставляю за собой право '
            'обратиться в суд, а также в Банк России и Роспотребнадзор.',
        ],
    ),
    'cbr_exclude.docx': dict(
        title='Заявление об исключении сведений из базы данных Банка России',
        fields=[('Кому', 'Банк России'), ('От', '[ваше ФИО, контактный телефон]')],
        body=[
            'Прошу рассмотреть вопрос об исключении сведений обо мне из базы данных Банка России, '
            'формируемой в соответствии со статьёй 9.1 Федерального закона № 161-ФЗ «О национальной '
            'платежной системе».',
            'Ранее ограничение было применено банком [название банка] __.__.____ по договору/счёту '
            '№ ____.',
            'Приложение: ответ банка о причинах ограничения (при наличии).',
        ],
    ),
    'cbr_complaint.docx': dict(
        title='Жалоба на бездействие банка',
        fields=[
            ('Кому', 'Банк России (Служба по защите прав потребителей и обеспечению доступности '
                      'финансовых услуг)'),
            ('От', '[ваше ФИО, контактный телефон]'),
        ],
        body=[
            'Прошу рассмотреть жалобу на бездействие [название банка], выразившееся в '
            'непредоставлении ответа или неисполнении обязанностей по договору в срок, установленный '
            'законодательством.',
            'Обстоятельства: ______.',
            'Приложение: копии обращений в банк и его ответы (при наличии).',
            'Прошу принять меры реагирования в отношении банка в соответствии с полномочиями Банка '
            'России.',
        ],
    ),
    'mvd_request.docx': dict(
        title='Заявление о предоставлении сведений о наличии либо отсутствии уголовного дела',
        fields=[
            ('Кому', '[наименование территориального органа МВД России по месту жительства]'),
            ('От', '[ваше ФИО, адрес, контактный телефон]'),
        ],
        body=[
            'Прошу сообщить, возбуждено ли в отношении меня уголовное дело либо ведётся ли '
            'доследственная проверка в связи с операциями по банковскому счёту/карте, ограниченными '
            'банком со ссылкой на признаки, установленные Федеральным законом № 161-ФЗ «О '
            'национальной платежной системе».',
            'Прошу направить письменный ответ по указанному адресу в порядке и сроки, '
            'предусмотренные Федеральным законом № 59-ФЗ «О порядке рассмотрения обращений граждан '
            'Российской Федерации» (не позднее 30 дней со дня регистрации обращения).',
        ],
    ),
}


def main():
    TEMPLATES_DIR.mkdir(exist_ok=True)
    for filename, content in DEFAULTS.items():
        doc = _build(content['title'], content['fields'], content['body'])
        path = TEMPLATES_DIR / filename
        doc.save(path)
        print(f'Written: {path}')


if __name__ == '__main__':
    main()
