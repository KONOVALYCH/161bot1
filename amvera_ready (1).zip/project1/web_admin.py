"""Web admin panel for the bot.

Runs inside the bot process (same event loop, same SQLite connection) and listens
only on 127.0.0.1, so it is reachable from this computer only. Pure aiohttp, no
JavaScript and no extra dependencies.

Security model:
  * login + password (scrypt hash in .env: WEB_PASSWORD_HASH), login attempts are throttled;
  * session cookie is HttpOnly + SameSite=Strict; every POST needs a CSRF token;
  * Host and Origin headers are checked (protection from DNS rebinding / foreign sites);
  * all user text is HTML-escaped.
"""

import base64
import hashlib
import hmac
import logging
import os
import secrets
import shutil
import struct
import time
import zipfile
from html import escape
from pathlib import Path
from urllib.parse import quote, urlparse

from aiohttp import web

from documents import data_dir, get_templates_dir

SESSION_TTL = 12 * 3600
PAGE_SIZE = 20
MAX_DOCX = 5 * 1024 * 1024
KEEP_BACKUPS = 5
DOCUMENTS = {
    'bank_return.docx': 'Банки: Заявление на возврат',
    'bank_justification.docx': 'Банки: Обоснование операции',
    'bank_complaint.docx': 'Банки: Досудебная претензия',
    'cbr_exclude.docx': 'ЦБ: Исключение из базы данных',
    'cbr_complaint.docx': 'ЦБ: Жалоба на бездействие банка',
    'mvd_request.docx': 'МВД: Запрос',
}
SYSTEM_SLUGS = {
    'community', 'faq', 'faq_115', 'faq_161', 'faq_mvd', 'tickets', 'paid_services',
    'banks', 'stories', 'about', 'cbr', 'mvd',
}
CATEGORY_NOTE = {'open': 'Открыто', 'closed': 'Закрыто'}
STORY_STATUS = {'pending': 'На модерации', 'published': 'Опубликованы', 'rejected': 'Отклонены'}


# --------------------------------------------------------------------------- passwords
def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2 ** 14, r=8, p=1, dklen=32)
    return f'scrypt${salt.hex()}${digest.hex()}'


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, salt_hex, digest_hex = stored.split('$')
        if scheme != 'scrypt':
            return False
        digest = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2 ** 14, r=8, p=1, dklen=32)
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def totp_code(secret: str, at=None, step=30, digits=6) -> str:
    """RFC 6238 one-time code (works with Google Authenticator, Aegis, etc.)."""
    key = base64.b32decode(secret.replace(' ', '').upper() + '=' * (-len(secret.replace(' ', '')) % 8))
    counter = int((time.time() if at is None else at) // step)
    digest = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    number = (struct.unpack('>I', digest[offset:offset + 4])[0] & 0x7FFFFFFF) % 10 ** digits
    return str(number).zfill(digits)


def verify_totp(secret: str, code: str) -> bool:
    code = (code or '').strip().replace(' ', '')
    now = time.time()
    return any(hmac.compare_digest(totp_code(secret, now + shift * 30), code) for shift in (-1, 0, 1))


def valid_https_url(text: str) -> bool:
    try:
        url = urlparse(text)
        url.port
        return text.startswith('https://') and bool(url.netloc) and bool(url.hostname) and not any(
            c.isspace() or ord(c) < 32 for c in text)
    except ValueError:
        return False


# --------------------------------------------------------------------------- html
CSS = """
:root{--bg:#f4f5f7;--card:#fff;--text:#1d2129;--muted:#6b7280;--line:#e3e6eb;--accent:#2563eb;--accent-text:#fff;--danger:#dc2626;--ok:#15803d;--warn:#b45309}
@media (prefers-color-scheme:dark){:root{--bg:#14161a;--card:#1d2026;--text:#e8eaed;--muted:#9aa1ac;--line:#2d3139;--accent:#4f8bff;--accent-text:#0b1220;--danger:#f87171;--ok:#4ade80;--warn:#fbbf24}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
a{color:var(--accent);text-decoration:none}a:hover{text-decoration:underline}
header{background:var(--card);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:5}
.nav{max-width:1000px;margin:0 auto;padding:0 16px;display:flex;gap:4px;align-items:center;flex-wrap:wrap}
.nav .brand{font-weight:700;margin-right:12px;padding:12px 0}
.nav a.tab{padding:14px 12px;color:var(--muted);border-bottom:2px solid transparent}
.nav a.tab.on{color:var(--text);border-color:var(--accent)}
.nav form{margin-left:auto}
main{max-width:1000px;margin:0 auto;padding:20px 16px 60px}
h1{font-size:22px;margin:0 0 16px}h2{font-size:17px;margin:24px 0 10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px}
.stat b{display:block;font-size:26px}.stat span{color:var(--muted);font-size:13px}
.muted{color:var(--muted)}.ok{color:var(--ok)}.bad{color:var(--danger)}.warn{color:var(--warn)}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{color:var(--muted);font-weight:600;font-size:13px}
label{display:block;font-weight:600;margin:12px 0 4px}
input[type=text],input[type=password],input[type=number],textarea{width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--text);font:inherit}
textarea{min-height:140px;resize:vertical}
.btn{display:inline-block;padding:8px 14px;border-radius:8px;border:1px solid var(--line);background:var(--card);color:var(--text);font:inherit;cursor:pointer}
.btn:hover{text-decoration:none;filter:brightness(.96)}
.btn.primary{background:var(--accent);border-color:var(--accent);color:var(--accent-text)}
.btn.danger{border-color:var(--danger);color:var(--danger)}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
.msg{white-space:pre-wrap;word-break:break-word}
.flash{padding:10px 14px;border-radius:8px;margin-bottom:14px;border:1px solid var(--line);background:var(--card)}
.flash.err{border-color:var(--danger);color:var(--danger)}.flash.good{border-color:var(--ok);color:var(--ok)}
.tree .item{display:flex;gap:10px;align-items:center;padding:8px 10px;border-bottom:1px solid var(--line)}
.badge{font-size:12px;padding:2px 8px;border-radius:999px;border:1px solid var(--line);color:var(--muted)}
details summary{cursor:pointer;display:inline-block}
.reply{border-left:3px solid var(--accent);padding:6px 12px;margin:8px 0;background:var(--bg);border-radius:0 8px 8px 0}
.login{max-width:360px;margin:12vh auto}
"""

NAV = [('/', 'Обзор', 'home'), ('/tickets', 'Обращения', 'tickets'), ('/stories', 'Истории', 'stories'),
       ('/menu', 'Меню бота', 'menu'), ('/services', 'Услуги', 'services'), ('/documents', 'Документы', 'documents'), ('/settings', 'Настройки', 'settings')]


def layout(title, body, active='', csrf='', flash=None):
    nav = ''
    if csrf:
        tabs = ''.join(f'<a class="tab{" on" if key == active else ""}" href="{href}">{label}</a>' for href, label, key in NAV)
        nav = (f'<header><div class="nav"><span class="brand">⚙️ Админ-панель бота</span>{tabs}'
               f'<form method="post" action="/logout"><input type="hidden" name="csrf" value="{csrf}">'
               f'<button class="btn" type="submit">Выйти</button></form></div></header>')
    note = ''
    if flash:
        kind, text = flash
        note = f'<div class="flash {kind}">{escape(text)}</div>'
    return (f'<!doctype html><html lang="ru"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{escape(title)} · Админ-панель</title><style>{CSS}</style></head>'
            f'<body>{nav}<main>{note}{body}</main></body></html>')


def csrf_field(csrf):
    return f'<input type="hidden" name="csrf" value="{csrf}">'


def short(text, n=110):
    text = ' '.join((text or '').split())
    return escape(text if len(text) <= n else text[:n] + '…')


# --------------------------------------------------------------------------- app
class WebAdmin:
    def __init__(self, store, admins, send_message, password_hash, username='admin',
                 env_path='.env', port=8080, templates_dir=None, extra_hosts=(),
                 secure_cookies=False, trust_proxy=False, totp_secret='', hash_file=None):
        self.store = store
        self.admins = sorted(admins)
        self.send_message = send_message  # async (user_id, text) -> bool
        self.password_hash = password_hash
        self.username = username
        self.env_path = env_path
        self.port = port
        self.templates_dir = Path(templates_dir or get_templates_dir())
        self.extra_hosts = [h.strip().lower() for h in extra_hosts if h.strip()]
        self.any_host = '*' in self.extra_hosts  # cloud: the public domain is not known in advance
        self.secure_cookies = secure_cookies
        self.trust_proxy = trust_proxy
        self.totp_secret = totp_secret
        self.hash_file = hash_file
        self.sessions = {}      # token -> {'csrf': str, 'expires': float}
        self.failures = []      # (client, timestamp) of failed logins
        self.app = web.Application(middlewares=[self.guard], client_max_size=MAX_DOCX + 512 * 1024)
        r = self.app.router
        r.add_get('/login', self.login_page)
        r.add_post('/login', self.login_post)
        r.add_post('/logout', self.logout)
        r.add_get('/', self.dashboard)
        r.add_get('/tickets', self.tickets)
        r.add_get('/tickets/{id:\\d+}', self.ticket_view)
        r.add_post('/tickets/{id:\\d+}/reply', self.ticket_reply)
        r.add_post('/tickets/{id:\\d+}/{op:close|reopen}', self.ticket_status)
        r.add_get('/stories', self.stories)
        r.add_post('/stories/{id:\\d+}/{op:publish|reject|pending}', self.story_op)
        r.add_get('/menu', self.menu)
        r.add_get('/menu/new', self.menu_new)
        r.add_post('/menu/new', self.menu_create)
        r.add_get('/menu/{id:\\d+}', self.menu_edit)
        r.add_post('/menu/{id:\\d+}/save', self.menu_save)
        r.add_post('/menu/{id:\\d+}/move/{dir:up|down}', self.menu_move)
        r.add_post('/menu/{id:\\d+}/delete', self.menu_delete)
        r.add_get('/services', self.services)
        r.add_get('/services/new', self.service_new)
        r.add_post('/services/new', self.service_create)
        r.add_get('/services/{id:\\d+}', self.service_edit)
        r.add_post('/services/{id:\\d+}/save', self.service_save)
        r.add_post('/services/{id:\\d+}/toggle', self.service_toggle)
        r.add_post('/services/{id:\\d+}/move/{dir:up|down}', self.service_move)
        r.add_post('/services/{id:\\d+}/delete', self.service_delete)
        r.add_get('/documents', self.documents)
        r.add_get('/documents/{name}/download', self.document_download)
        r.add_post('/documents/{name}/upload', self.document_upload)
        r.add_post('/documents/{name}/restore', self.document_restore)
        r.add_get('/settings', self.settings)
        r.add_post('/settings/password', self.change_password)

    # ----------------------------------------------------------- security plumbing
    def allowed_hosts(self):
        hosts = {f'127.0.0.1:{self.port}', f'localhost:{self.port}', f'[::1]:{self.port}'}
        for name in self.extra_hosts:
            hosts.update({name, f'{name}:{self.port}'})
        return hosts

    def session_of(self, request):
        token = request.cookies.get('sid', '')
        session = self.sessions.get(token)
        if session and session['expires'] > time.time():
            return token, session
        self.sessions.pop(token, None)
        return None, None

    @web.middleware
    async def guard(self, request, handler):
        if not self.any_host and request.host not in self.allowed_hosts():
            return web.Response(status=400, text='Bad host')
        if request.method == 'POST':
            origin = request.headers.get('Origin')
            if origin:
                netloc = urlparse(origin).netloc
                if not (netloc in self.allowed_hosts() or (self.any_host and netloc == request.host)):
                    return web.Response(status=403, text='Bad origin')
        token, session = self.session_of(request)
        request['session'] = session
        request['csrf'] = session['csrf'] if session else ''
        if request.path != '/login' and not session:
            raise web.HTTPSeeOther('/login')
        if request.method == 'POST' and request.path != '/login':
            form = await request.post()
            if not hmac.compare_digest(str(form.get('csrf', '')), session['csrf']):
                return web.Response(status=403, text='CSRF check failed. Go back, reload the page and try again.')
            request['form'] = form
        try:
            response = await handler(request)
        except web.HTTPException:
            raise
        except Exception:
            logging.exception('Web admin error at %s', request.path)
            response = web.Response(status=500, text='Внутренняя ошибка. Подробности в bot.log.')
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Referrer-Policy'] = 'same-origin'
        if self.secure_cookies:
            response.headers['Strict-Transport-Security'] = 'max-age=31536000'
        response.headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"
        return response

    def html(self, request, title, body, active='', flash=None, status=200):
        return web.Response(text=layout(title, body, active, request['csrf'], flash), content_type='text/html', status=status)

    def flash_from(self, request):
        msg = request.query.get('m')
        if msg:
            return ('err' if request.query.get('e') else 'good', msg[:300])
        return None

    def back(self, path, message, error=False):
        raise web.HTTPSeeOther(f'{path}{"&" if "?" in path else "?"}m={quote(message)}{"&e=1" if error else ""}')

    # ----------------------------------------------------------- login
    async def login_page(self, request, flash=None):
        body = ('<div class="login card"><h1>Вход</h1><form method="post" action="/login">'
                '<label>Логин</label><input type="text" name="user" autofocus autocomplete="username">'
                '<label>Пароль</label><input type="password" name="password" autocomplete="current-password">'
                + ('<label>Код из приложения-аутентификатора</label><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code">' if self.totp_secret else '')
                + '<p><button class="btn primary" type="submit">Войти</button></p></form></div>')
        return self.html(request, 'Вход', body, flash=flash)

    def client_ip(self, request):
        if self.trust_proxy:
            forwarded = request.headers.get('X-Forwarded-For', '')
            if forwarded:
                return forwarded.split(',')[-1].strip()  # the entry added by our own proxy
        return request.remote or '?'

    async def login_post(self, request):
        now = time.time()
        ip = self.client_ip(request)
        self.failures = [(c, t) for c, t in self.failures if now - t < 3600]
        mine = sum(1 for c, t in self.failures if c == ip and now - t < 300)
        if mine >= 5 or len(self.failures) >= 40:
            return await self.login_page(request, ('err', 'Слишком много неудачных попыток. Подождите 5 минут.'))
        form = await request.post()
        ok_user = hmac.compare_digest(str(form.get('user', '')), self.username)
        ok_pass = verify_password(str(form.get('password', '')), self.password_hash)
        ok_code = verify_totp(self.totp_secret, str(form.get('code', ''))) if self.totp_secret else True
        if not (ok_user and ok_pass and ok_code):
            self.failures.append((ip, now))
            logging.warning('Web admin: failed login attempt from %s', ip)
            return await self.login_page(request, ('err', 'Неверный логин, пароль или код.' if self.totp_secret else 'Неверный логин или пароль.'))
        self.failures = [(c, t) for c, t in self.failures if c != ip]
        token = secrets.token_urlsafe(32)
        self.sessions[token] = {'csrf': secrets.token_urlsafe(24), 'expires': now + SESSION_TTL}
        response = web.HTTPSeeOther('/')
        response.set_cookie('sid', token, max_age=SESSION_TTL, httponly=True, samesite='Strict', path='/', secure=self.secure_cookies)
        raise response

    async def logout(self, request):
        self.sessions.pop(request.cookies.get('sid', ''), None)
        response = web.HTTPSeeOther('/login')
        response.del_cookie('sid', path='/')
        raise response

    # ----------------------------------------------------------- dashboard
    async def dashboard(self, request):
        s = await self.store.stats()
        clicks = await self.store.click_stats()
        sections = [r for r in clicks if r['name'].startswith('click:section:')][:15]
        frequent = clicks[:10]

        def stat(value, label, href=None):
            inner = f'<b>{value}</b><span>{label}</span>'
            return f'<a class="stat" href="{href}" style="color:inherit">{inner}</a>' if href else f'<div class="stat">{inner}</div>'

        def rows(items, strip):
            if not items:
                return '<p class="muted">Нет данных</p>'
            return '<table>' + ''.join(f'<tr><td>{escape(r["name"][strip:])}</td><td style="text-align:right">{r["n"]}</td></tr>' for r in items) + '</table>'

        body = (
            '<h1>Обзор</h1><div class="grid">'
            + stat(s['users'], 'пользователей')
            + stat(s['new_users'], 'новых за 7 дней')
            + stat(s['active'], 'активных за 24 часа')
            + stat(s['open_tickets'], 'открытых обращений', '/tickets?status=open')
            + stat(s['closed_tickets'], 'закрытых обращений', '/tickets?status=closed')
            + stat(s['replies'], 'доставленных ответов')
            + stat(s['pending'], 'историй на модерации', '/stories?status=pending')
            + stat(s['published'], 'историй опубликовано', '/stories?status=published')
            + '</div><p class="muted">Общие показатели включают администраторов.</p>'
            '<h2>Популярные разделы за 7 дней</h2><div class="card">' + rows(sections, len('click:section:')) + '</div>'
            '<h2>Частые кнопки</h2><div class="card">' + rows(frequent, 6) + '</div>'
            '<p class="muted">Клики без администраторов. Запрос ссылки чата — это не переход и не вступление.</p>')
        return self.html(request, 'Обзор', body, 'home', self.flash_from(request))

    # ----------------------------------------------------------- tickets
    async def tickets(self, request):
        status = request.query.get('status', 'open')
        status = status if status in CATEGORY_NOTE else 'open'
        page = max(0, int(request.query.get('page', '0') or 0)) if request.query.get('page', '0').isdigit() else 0
        rows = await self.store.rows(
            'SELECT t.*, (SELECT COUNT(*) FROM replies r WHERE r.ticket_id=t.id) AS replies '
            'FROM tickets t WHERE status=? ORDER BY id DESC LIMIT ? OFFSET ?', (status, PAGE_SIZE + 1, page * PAGE_SIZE))
        tabs = ''.join(f'<a class="btn{" primary" if k == status else ""}" href="/tickets?status={k}">{v}</a>' for k, v in CATEGORY_NOTE.items())
        items = ''.join(
            f'<tr><td><a href="/tickets/{r["id"]}">№{r["id"]}</a></td><td>{escape(r["category"])}</td>'
            f'<td>{short(r["body"])}</td><td class="muted">{escape(r["created_at"])}</td><td>{r["replies"]}</td></tr>'
            for r in rows[:PAGE_SIZE])
        table = ('<table><tr><th>№</th><th>Тема</th><th>Текст</th><th>Создано (UTC)</th><th>Ответов</th></tr>' + items + '</table>') if items else '<p class="muted">Здесь пусто.</p>'
        pager = ''
        if page:
            pager += f'<a class="btn" href="/tickets?status={status}&page={page - 1}">← Новее</a> '
        if len(rows) > PAGE_SIZE:
            pager += f'<a class="btn" href="/tickets?status={status}&page={page + 1}">Старее →</a>'
        body = f'<h1>Обращения</h1><div class="row" style="margin-bottom:12px">{tabs}</div><div class="card">{table}</div><div class="row">{pager}</div>'
        return self.html(request, 'Обращения', body, 'tickets', self.flash_from(request))

    async def ticket_view(self, request):
        tid = int(request.match_info['id'])
        t = await self.store.one('SELECT * FROM tickets WHERE id=?', (tid,))
        if not t:
            return self.html(request, 'Не найдено', '<h1>Обращение не найдено</h1><a href="/tickets">← К списку</a>', 'tickets', status=404)
        replies = await self.store.rows('SELECT * FROM replies WHERE ticket_id=? ORDER BY id', (tid,))
        thread = ''.join(
            f'<div class="reply"><div class="muted">{escape(r["created_at"])} UTC · '
            f'{"<span class=ok>доставлено</span>" if r["delivered"] else "<span class=bad>не доставлено в Telegram</span>"}</div>'
            f'<div class="msg">{escape(r["body"])}</div></div>' for r in replies) or '<p class="muted">Ответов пока нет.</p>'
        csrf = request['csrf']
        if t['status'] == 'open':
            form = (f'<h2>Ответить пользователю</h2><form class="card" method="post" action="/tickets/{tid}/reply">{csrf_field(csrf)}'
                    '<textarea name="body" maxlength="2500" required placeholder="Текст ответа, до 2500 символов"></textarea>'
                    '<p class="row"><button class="btn primary" type="submit">Отправить в Telegram</button></p></form>'
                    f'<form method="post" action="/tickets/{tid}/close">{csrf_field(csrf)}<button class="btn" type="submit">✅ Закрыть обращение</button></form>')
        else:
            form = f'<form method="post" action="/tickets/{tid}/reopen">{csrf_field(csrf)}<button class="btn" type="submit">↩️ Открыть снова</button></form>'
        body = (f'<p><a href="/tickets?status={t["status"]}">← К списку</a></p><h1>Обращение №{tid}</h1>'
                f'<div class="card"><div class="muted">{escape(t["category"])} · {escape(t["created_at"])} UTC · '
                f'{CATEGORY_NOTE.get(t["status"], t["status"])} · ID пользователя Telegram: {t["user_id"]}</div>'
                f'<p class="msg">{escape(t["body"])}</p></div><h2>Переписка</h2>{thread}{form}')
        return self.html(request, f'Обращение №{tid}', body, 'tickets', self.flash_from(request))

    async def ticket_reply(self, request):
        tid = int(request.match_info['id'])
        text = str(request['form'].get('body', '')).strip()
        t = await self.store.one("SELECT * FROM tickets WHERE id=? AND status='open'", (tid,))
        if not t:
            self.back(f'/tickets/{tid}', 'Обращение закрыто или удалено.', True)
        if not 1 <= len(text) <= 2500:
            self.back(f'/tickets/{tid}', 'Ответ должен быть от 1 до 2500 символов.', True)
        rid = await self.store.execute('INSERT INTO replies(ticket_id, admin_id, body) VALUES (?,?,?)', (tid, self.admins[0], text))
        delivered = await self.send_message(t['user_id'], f'<b>Ответ по обращению №{tid}</b>\n\n{escape(text)}')
        if delivered:
            await self.store.execute('UPDATE replies SET delivered=1 WHERE id=?', (rid,))
            self.back(f'/tickets/{tid}', 'Ответ доставлен пользователю в Telegram.')
        self.back(f'/tickets/{tid}', 'Ответ сохранён, но Telegram его не доставил. Пользователь увидит его в разделе «Мои обращения».', True)

    async def ticket_status(self, request):
        tid = int(request.match_info['id'])
        op = request.match_info['op']
        await self.store.execute('UPDATE tickets SET status=? WHERE id=?', ('closed' if op == 'close' else 'open', tid))
        self.back(f'/tickets/{tid}', 'Обращение закрыто.' if op == 'close' else 'Обращение снова открыто.')

    # ----------------------------------------------------------- stories
    async def stories(self, request):
        status = request.query.get('status', 'pending')
        status = status if status in STORY_STATUS else 'pending'
        page = int(request.query['page']) if request.query.get('page', '').isdigit() else 0
        rows = await self.store.rows('SELECT * FROM stories WHERE status=? ORDER BY id DESC LIMIT ? OFFSET ?',
                                     (status, PAGE_SIZE + 1, page * PAGE_SIZE))
        csrf = request['csrf']
        tabs = ''.join(f'<a class="btn{" primary" if k == status else ""}" href="/stories?status={k}">{v}</a>' for k, v in STORY_STATUS.items())
        cards = ''
        for r in rows[:PAGE_SIZE]:
            def btn(op, label, cls=''):
                return (f'<form method="post" action="/stories/{r["id"]}/{op}">{csrf_field(csrf)}'
                        f'<input type="hidden" name="back" value="{status}"><button class="btn {cls}" type="submit">{label}</button></form>')
            actions = ''
            if status != 'published':
                actions += btn('publish', '✅ Опубликовать', 'primary')
            if status != 'rejected':
                actions += btn('reject', '🚫 Отклонить', 'danger')
            if status != 'pending':
                actions += btn('pending', '↩️ Вернуть на модерацию')
            cards += (f'<div class="card"><div class="muted">История №{r["id"]} · {escape(r["created_at"])} UTC</div>'
                      f'<p class="msg">{escape(r["body"])}</p><div class="row">{actions}</div></div>')
        pager = ''
        if page:
            pager += f'<a class="btn" href="/stories?status={status}&page={page - 1}">← Новее</a> '
        if len(rows) > PAGE_SIZE:
            pager += f'<a class="btn" href="/stories?status={status}&page={page + 1}">Старее →</a>'
        body = (f'<h1>Истории</h1><div class="row" style="margin-bottom:12px">{tabs}</div>'
                + (cards or '<div class="card muted">Здесь пусто.</div>') + f'<div class="row">{pager}</div>'
                '<p class="muted">Перед публикацией проверьте, нет ли в тексте персональных данных и предложений «разблокировки за деньги».</p>')
        return self.html(request, 'Истории', body, 'stories', self.flash_from(request))

    async def story_op(self, request):
        sid = int(request.match_info['id'])
        op = request.match_info['op']
        status = {'publish': 'published', 'reject': 'rejected', 'pending': 'pending'}[op]
        await self.store.execute('UPDATE stories SET status=?, moderator_id=? WHERE id=?', (status, self.admins[0], sid))
        back = str(request['form'].get('back', 'pending'))
        back = back if back in STORY_STATUS else 'pending'
        self.back(f'/stories?status={back}', {'published': 'История опубликована.', 'rejected': 'История отклонена.', 'pending': 'История возвращена на модерацию.'}[status])

    # ----------------------------------------------------------- menu editor
    async def menu(self, request):
        rows = await self.store.rows('SELECT * FROM sections ORDER BY position, id')
        children = {}
        for r in rows:
            children.setdefault(r['parent_id'], []).append(r)
        out = []

        def walk(parent, depth):
            for r in children.get(parent, []):
                url = ' <span class="badge">🔗 ссылка</span>' if r['url'] else ''
                system = ' <span class="badge">системный</span>' if r['slug'] in SYSTEM_SLUGS or r['slug'] == 'home' else ''
                out.append(f'<div class="item" style="padding-left:{10 + depth * 26}px"><a href="/menu/{r["id"]}"><b>{escape(r["title"])}</b></a>{system}{url}'
                           f'<span class="muted" style="margin-left:auto">{short(r["body"], 60)}</span></div>')
                walk(r['id'], depth + 1)
        walk(None, 0)
        body = ('<h1>Меню бота</h1><p class="muted">Разделы и подразделы так, как их видят пользователи. Нажмите на название, чтобы изменить.</p>'
                '<p><a class="btn primary" href="/menu/new">➕ Добавить пункт</a></p><div class="card tree" style="padding:0">' + ''.join(out) + '</div>')
        return self.html(request, 'Меню бота', body, 'menu', self.flash_from(request))

    async def menu_edit(self, request):
        sid = int(request.match_info['id'])
        s = await self.store.one('SELECT * FROM sections WHERE id=?', (sid,))
        if not s:
            return self.html(request, 'Не найдено', '<h1>Пункт не найден</h1><a href="/menu">← К меню</a>', 'menu', status=404)
        csrf = request['csrf']
        subs = await self.store.rows('SELECT id, title FROM sections WHERE parent_id=? ORDER BY position, id', (sid,))
        sublist = ''.join(f'<li><a href="/menu/{c["id"]}">{escape(c["title"])}</a></li>' for c in subs)
        warn = ''
        if s['slug'] in SYSTEM_SLUGS:
            warn = '<p class="warn">⚠️ Системный раздел: с ним связано отдельное поведение бота (документы, обращения, услуги, FAQ). После удаления связанная функция пропадёт из меню.</p>'
        community = ''
        if s['slug'] == 'community':
            community = '<p class="muted">Для этого раздела поле «Ссылка» — это ссылка на чат участников, которую бот выдаёт по кнопке «Получить ссылку на чат».</p>'
        delete = ''
        if s['slug'] != 'home':
            delete = (f'<details style="margin-top:16px"><summary class="btn danger">🗑 Удалить пункт</summary>'
                      f'<form method="post" action="/menu/{sid}/delete" class="card" style="margin-top:8px">{csrf_field(csrf)}{warn}'
                      f'<p>Удалить «{escape(s["title"])}» без возможности восстановления?</p><button class="btn danger" type="submit">Да, удалить</button></form></details>')
        body = (f'<p><a href="/menu">← К меню</a></p><h1>{escape(s["title"])}</h1>'
                f'<form class="card" method="post" action="/menu/{sid}/save">{csrf_field(csrf)}'
                f'<label>Заголовок (до 80 символов)</label><input type="text" name="title" maxlength="80" required value="{escape(s["title"], quote=True)}">'
                f'<label>Текст (до 2500 символов)</label><textarea name="body" maxlength="2500" required>{escape(s["body"])}</textarea>'
                f'<label>Ссылка (https://…, можно оставить пустой)</label><input type="text" name="url" maxlength="2048" value="{escape(s["url"] or "", quote=True)}">{community}'
                '<p><button class="btn primary" type="submit">Сохранить</button></p></form>'
                '<div class="row">'
                f'<form method="post" action="/menu/{sid}/move/up">{csrf_field(csrf)}<button class="btn" type="submit">⬆️ Выше</button></form>'
                f'<form method="post" action="/menu/{sid}/move/down">{csrf_field(csrf)}<button class="btn" type="submit">⬇️ Ниже</button></form>'
                f'<a class="btn" href="/menu/new?parent={sid}">➕ Добавить подраздел</a></div>'
                + (f'<h2>Подразделы</h2><div class="card"><ul>{sublist}</ul></div>' if subs else '') + delete)
        return self.html(request, s['title'], body, 'menu', self.flash_from(request))

    def clean_section_form(self, form):
        title = str(form.get('title', '')).strip()
        text = str(form.get('body', '')).strip()
        url = str(form.get('url', '')).strip()
        if not 1 <= len(title) <= 80:
            return None, 'Заголовок должен быть от 1 до 80 символов.'
        if not 1 <= len(text) <= 2500:
            return None, 'Текст должен быть от 1 до 2500 символов.'
        if url and (len(url) > 2048 or not valid_https_url(url)):
            return None, 'Ссылка должна быть корректным адресом https://…'
        return (title, text, url), None

    async def menu_save(self, request):
        sid = int(request.match_info['id'])
        if not await self.store.one('SELECT id FROM sections WHERE id=?', (sid,)):
            self.back('/menu', 'Пункт не найден.', True)
        data, error = self.clean_section_form(request['form'])
        if error:
            self.back(f'/menu/{sid}', error, True)
        await self.store.execute('UPDATE sections SET title=?, body=?, url=? WHERE id=?', (*data, sid))
        self.back(f'/menu/{sid}', 'Сохранено. Изменения сразу видны в боте.')

    async def menu_new(self, request):
        parent = request.query.get('parent', '')
        parents = await self.store.rows('SELECT id, title FROM sections ORDER BY position, id')
        home = await self.store.one("SELECT id FROM sections WHERE slug='home'")
        chosen = int(parent) if parent.isdigit() else (home['id'] if home else 0)
        options = ''.join(f'<option value="{p["id"]}"{" selected" if p["id"] == chosen else ""}>{escape(p["title"])}</option>' for p in parents)
        csrf = request['csrf']
        style = 'width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--text);font:inherit'
        body = (f'<p><a href="/menu">← К меню</a></p><h1>Новый пункт меню</h1><form class="card" method="post" action="/menu/new">{csrf_field(csrf)}'
                f'<label>Родительский раздел</label><select name="parent" style="{style}">{options}</select>'
                '<label>Заголовок (до 80 символов)</label><input type="text" name="title" maxlength="80" required>'
                '<label>Текст (до 2500 символов)</label><textarea name="body" maxlength="2500" required></textarea>'
                '<label>Ссылка (https://…, необязательно)</label><input type="text" name="url" maxlength="2048">'
                '<p><button class="btn primary" type="submit">Создать</button></p></form>')
        return self.html(request, 'Новый пункт', body, 'menu', self.flash_from(request))

    async def menu_create(self, request):
        form = request['form']
        parent = str(form.get('parent', ''))
        if not parent.isdigit() or not await self.store.one('SELECT id FROM sections WHERE id=?', (int(parent),)):
            self.back('/menu/new', 'Родительский раздел не найден.', True)
        data, error = self.clean_section_form(form)
        if error:
            self.back(f'/menu/new?parent={parent}', error, True)
        maxrow = await self.store.one('SELECT COALESCE(MAX(position), -1) AS p FROM sections WHERE parent_id IS ?', (int(parent),))
        new_id = await self.store.execute('INSERT INTO sections(parent_id,title,body,position,url) VALUES (?,?,?,?,?)',
                                          (int(parent), data[0], data[1], int(maxrow['p']) + 1, data[2]))
        self.back(f'/menu/{new_id}', 'Пункт создан.')

    async def menu_move(self, request):
        sid = int(request.match_info['id'])
        up = request.match_info['dir'] == 'up'
        s = await self.store.one('SELECT * FROM sections WHERE id=?', (sid,))
        if s:
            if up:
                n = await self.store.one('SELECT * FROM sections WHERE parent_id IS ? AND position < ? ORDER BY position DESC, id DESC LIMIT 1', (s['parent_id'], s['position']))
            else:
                n = await self.store.one('SELECT * FROM sections WHERE parent_id IS ? AND position > ? ORDER BY position ASC, id ASC LIMIT 1', (s['parent_id'], s['position']))
            if n:
                await self.store.db.execute('UPDATE sections SET position=? WHERE id=?', (n['position'], s['id']))
                await self.store.db.execute('UPDATE sections SET position=? WHERE id=?', (s['position'], n['id']))
                await self.store.db.commit()
        self.back(f'/menu/{sid}', 'Порядок изменён.')

    async def menu_delete(self, request):
        sid = int(request.match_info['id'])
        s = await self.store.one('SELECT * FROM sections WHERE id=?', (sid,))
        if not s:
            self.back('/menu', 'Пункт не найден.', True)
        if s['slug'] == 'home':
            self.back(f'/menu/{sid}', 'Главное меню удалить нельзя.', True)
        if await self.store.one('SELECT id FROM sections WHERE parent_id=? LIMIT 1', (sid,)):
            self.back(f'/menu/{sid}', 'Сначала удалите или перенесите подразделы этого пункта.', True)
        await self.store.execute('DELETE FROM sections WHERE id=?', (sid,))
        self.back('/menu', 'Пункт меню удалён.')

    # ----------------------------------------------------------- paid services
    @staticmethod
    def money(value):
        return f'{int(value):,}'.replace(',', ' ') + ' ₽'

    async def services(self, request):
        rows = await self.store.rows('SELECT * FROM paid_services ORDER BY position, id')
        items = ''.join(
            f'<tr><td><a href="/services/{r["id"]}"><b>{escape(r["title"])}</b></a></td><td>{self.money(r["price"])}</td>'
            f'<td>{"<span class=ok>опубликована</span>" if r["active"] else "<span class=muted>скрыта</span>"}</td></tr>' for r in rows)
        table = f'<table><tr><th>Услуга</th><th>Цена</th><th>Статус</th></tr>{items}</table>' if rows else '<p class="muted">Услуг пока нет.</p>'
        body = f'<h1>Платные услуги</h1><p><a class="btn primary" href="/services/new">➕ Добавить услугу</a></p><div class="card">{table}</div>'
        return self.html(request, 'Услуги', body, 'services', self.flash_from(request))

    def service_form(self, action, csrf, title='', desc='', price=''):
        return (f'<form class="card" method="post" action="{action}">{csrf_field(csrf)}'
                f'<label>Название (до 100 символов)</label><input type="text" name="title" maxlength="100" required value="{escape(str(title), quote=True)}">'
                f'<label>Описание (до 1500 символов, можно пустое)</label><textarea name="description" maxlength="1500">{escape(desc)}</textarea>'
                f'<label>Цена, ₽ (целое число от 0 до 10 000 000)</label><input type="number" name="price" min="0" max="10000000" required value="{escape(str(price), quote=True)}">'
                '<p><button class="btn primary" type="submit">Сохранить</button></p></form>')

    @staticmethod
    def clean_service(form):
        title = str(form.get('title', '')).strip()
        desc = str(form.get('description', '')).strip()
        raw = str(form.get('price', '')).replace(' ', '').replace('₽', '')
        try:
            price = int(raw)
        except ValueError:
            price = -1
        if not 1 <= len(title) <= 100:
            return None, 'Название должно быть от 1 до 100 символов.'
        if len(desc) > 1500:
            return None, 'Описание не должно превышать 1500 символов.'
        if not 0 <= price <= 10_000_000:
            return None, 'Цена должна быть целым числом от 0 до 10 000 000 рублей.'
        return (title, desc, price), None

    async def service_new(self, request):
        body = '<p><a href="/services">← К услугам</a></p><h1>Новая услуга</h1>' + self.service_form('/services/new', request['csrf'])
        return self.html(request, 'Новая услуга', body, 'services', self.flash_from(request))

    async def service_create(self, request):
        data, error = self.clean_service(request['form'])
        if error:
            self.back('/services/new', error, True)
        maxrow = await self.store.one('SELECT COALESCE(MAX(position), -1) AS p FROM paid_services')
        sid = await self.store.execute('INSERT INTO paid_services(title,description,price,position,active) VALUES (?,?,?,?,1)',
                                       (*data, int(maxrow['p']) + 1))
        self.back(f'/services/{sid}', 'Услуга добавлена и опубликована.')

    async def service_edit(self, request):
        sid = int(request.match_info['id'])
        s = await self.store.one('SELECT * FROM paid_services WHERE id=?', (sid,))
        if not s:
            return self.html(request, 'Не найдено', '<h1>Услуга не найдена</h1><a href="/services">← К услугам</a>', 'services', status=404)
        csrf = request['csrf']
        body = (f'<p><a href="/services">← К услугам</a></p><h1>{escape(s["title"])}</h1>'
                + self.service_form(f'/services/{sid}/save', csrf, s['title'], s['description'], s['price'])
                + '<div class="row">'
                f'<form method="post" action="/services/{sid}/toggle">{csrf_field(csrf)}<button class="btn" type="submit">{"⛔ Скрыть" if s["active"] else "✅ Опубликовать"}</button></form>'
                f'<form method="post" action="/services/{sid}/move/up">{csrf_field(csrf)}<button class="btn" type="submit">⬆️ Выше</button></form>'
                f'<form method="post" action="/services/{sid}/move/down">{csrf_field(csrf)}<button class="btn" type="submit">⬇️ Ниже</button></form></div>'
                f'<details style="margin-top:16px"><summary class="btn danger">🗑 Удалить услугу</summary><form method="post" action="/services/{sid}/delete" class="card" style="margin-top:8px">'
                f'{csrf_field(csrf)}<p>Удалить «{escape(s["title"])}» без возможности восстановления?</p><button class="btn danger" type="submit">Да, удалить</button></form></details>')
        return self.html(request, s['title'], body, 'services', self.flash_from(request))

    async def service_save(self, request):
        sid = int(request.match_info['id'])
        data, error = self.clean_service(request['form'])
        if error:
            self.back(f'/services/{sid}', error, True)
        await self.store.execute('UPDATE paid_services SET title=?, description=?, price=? WHERE id=?', (*data, sid))
        self.back(f'/services/{sid}', 'Сохранено.')

    async def service_toggle(self, request):
        sid = int(request.match_info['id'])
        await self.store.execute('UPDATE paid_services SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?', (sid,))
        self.back(f'/services/{sid}', 'Статус изменён.')

    async def service_move(self, request):
        sid = int(request.match_info['id'])
        up = request.match_info['dir'] == 'up'
        s = await self.store.one('SELECT * FROM paid_services WHERE id=?', (sid,))
        if s:
            if up:
                n = await self.store.one('SELECT * FROM paid_services WHERE position < ? ORDER BY position DESC, id DESC LIMIT 1', (s['position'],))
            else:
                n = await self.store.one('SELECT * FROM paid_services WHERE position > ? ORDER BY position ASC, id ASC LIMIT 1', (s['position'],))
            if n:
                await self.store.db.execute('UPDATE paid_services SET position=? WHERE id=?', (n['position'], sid))
                await self.store.db.execute('UPDATE paid_services SET position=? WHERE id=?', (s['position'], n['id']))
                await self.store.db.commit()
        self.back(f'/services/{sid}', 'Порядок изменён.')

    async def service_delete(self, request):
        sid = int(request.match_info['id'])
        await self.store.execute('DELETE FROM paid_services WHERE id=?', (sid,))
        self.back('/services', 'Услуга удалена.')


    # ----------------------------------------------------------- document templates
    def doc_path(self, name):
        if name not in DOCUMENTS:
            raise web.HTTPNotFound()
        return self.templates_dir / name

    def doc_backups(self, name):
        folder = self.templates_dir / 'backups'
        return sorted(folder.glob(name[:-5] + '.*.docx'), reverse=True) if folder.is_dir() else []

    @staticmethod
    def check_docx(data):
        """Return an error text, or None when data looks like a real Word document."""
        import io
        if len(data) > MAX_DOCX:
            return 'Файл больше 5 МБ.'
        if not data.startswith(b'PK'):
            return 'Это не файл .docx (Word). Сохраните документ в Word как «Документ Word (.docx)».'
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = set(z.namelist())
                if '[Content_Types].xml' not in names or 'word/document.xml' not in names:
                    return 'Файл не похож на документ Word (.docx).'
                if sum(i.file_size for i in z.infolist()) > 60 * 1024 * 1024:
                    return 'Файл слишком большой после распаковки.'
                if z.testzip() is not None:
                    return 'Файл повреждён.'
        except zipfile.BadZipFile:
            return 'Файл повреждён или не является .docx.'
        return None

    def write_doc(self, path, data):
        """Back up the current file, then replace it atomically."""
        self.templates_dir.mkdir(parents=True, exist_ok=True)
        if path.is_file():
            folder = self.templates_dir / 'backups'
            folder.mkdir(exist_ok=True)
            stamp = time.strftime('%Y%m%d-%H%M%S')
            shutil.copy2(path, folder / f'{path.stem}.{stamp}.docx')
            for old in self.doc_backups(path.name)[KEEP_BACKUPS:]:
                old.unlink(missing_ok=True)
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_bytes(data)
        os.replace(tmp, path)

    async def documents(self, request):
        csrf = request['csrf']
        cards = ''
        for name, title in DOCUMENTS.items():
            path = self.templates_dir / name
            if path.is_file():
                st = path.stat()
                info = f'{st.st_size // 1024 + 1} КБ · изменён {time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime))}'
                download = f'<a class="btn" href="/documents/{name}/download">⬇️ Скачать текущий</a>'
            else:
                info = '<span class="bad">файл отсутствует: пользователям придёт сообщение об ошибке</span>'
                download = ''
            restore = ''
            if self.doc_backups(name):
                restore = (f'<form method="post" action="/documents/{name}/restore">{csrf_field(csrf)}'
                           '<button class="btn" type="submit">↩️ Вернуть предыдущую версию</button></form>')
            cards += (f'<div class="card"><b>{escape(title)}</b> <span class="muted">· {name}</span><div class="muted">{info}</div>'
                      f'<form method="post" action="/documents/{name}/upload" enctype="multipart/form-data" class="row" style="margin-top:10px">{csrf_field(csrf)}'
                      '<input type="file" name="file" accept=".docx" required>'
                      '<button class="btn primary" type="submit">Заменить файл</button></form>'
                      f'<div class="row" style="margin-top:8px">{download}{restore}</div></div>')
        body = ('<h1>Документы-шаблоны</h1><p class="muted">Эти файлы бот отправляет пользователям. Скачайте текущий, отредактируйте в Word и загрузите обратно: '
                'новая версия сразу заработает, перезапуск не нужен. Перед заменой старая версия сохраняется (последние 5 копий).</p>' + cards)
        return self.html(request, 'Документы', body, 'documents', self.flash_from(request))

    async def document_download(self, request):
        name = request.match_info['name']
        path = self.doc_path(name)
        if not path.is_file():
            raise web.HTTPNotFound()
        return web.FileResponse(path, headers={'Content-Disposition': f"attachment; filename*=UTF-8''{quote(DOCUMENTS[name])}.docx"})

    async def document_upload(self, request):
        name = request.match_info['name']
        path = self.doc_path(name)
        field = request['form'].get('file')
        if field is None or not hasattr(field, 'file'):
            self.back('/documents', 'Выберите файл .docx.', True)
        data = field.file.read(MAX_DOCX + 1)
        error = self.check_docx(data)
        if error:
            self.back('/documents', error, True)
        self.write_doc(path, data)
        self.back('/documents', f'«{DOCUMENTS[name]}» заменён. Новая версия уже доступна в боте.')

    async def document_restore(self, request):
        name = request.match_info['name']
        path = self.doc_path(name)
        backups = self.doc_backups(name)
        if not backups:
            self.back('/documents', 'Предыдущих версий нет.', True)
        data = backups[0].read_bytes()
        self.write_doc(path, data)  # current file is backed up too, so restore can be undone
        backups[0].unlink(missing_ok=True)
        self.back('/documents', f'«{DOCUMENTS[name]}»: возвращена предыдущая версия.')

    # ----------------------------------------------------------- settings
    async def settings(self, request):
        community = await self.store.one("SELECT id, url FROM sections WHERE slug='community'")
        link = ''
        if community:
            current = escape(community['url']) if community['url'] else 'не задана'
            link = (f'<div class="card"><b>Ссылка на чат участников:</b> {current}<br>'
                    f'<a href="/menu/{community["id"]}">Изменить в разделе «Чат участников» →</a></div>')
        csrf = request['csrf']
        body = ('<h1>Настройки</h1><h2>Чат участников</h2>' + (link or '<p class="muted">Раздел не найден.</p>')
                + '<h2>Сменить пароль сайта</h2>'
                f'<form class="card" method="post" action="/settings/password">{csrf_field(csrf)}'
                '<label>Текущий пароль</label><input type="password" name="old" autocomplete="current-password" required>'
                '<label>Новый пароль (не короче 10 символов)</label><input type="password" name="new" autocomplete="new-password" minlength="10" required>'
                '<p><button class="btn primary" type="submit">Сменить пароль</button></p></form>'
                '<h2>Администраторы бота</h2><div class="card">Telegram ID: ' + ', '.join(str(a) for a in self.admins)
                + '<p class="muted">Список задаётся в файле .env (ADMIN_IDS) и применяется после перезапуска бота.</p></div>')
        return self.html(request, 'Настройки', body, 'settings', self.flash_from(request))

    async def change_password(self, request):
        form = request['form']
        if not verify_password(str(form.get('old', '')), self.password_hash):
            self.back('/settings', 'Текущий пароль указан неверно.', True)
        new = str(form.get('new', ''))
        if len(new) < 10:
            self.back('/settings', 'Новый пароль должен быть не короче 10 символов.', True)
        new_hash = hash_password(new)
        if self.hash_file:
            Path(self.hash_file).parent.mkdir(parents=True, exist_ok=True)
            Path(self.hash_file).write_text(new_hash)
            try:
                os.chmod(self.hash_file, 0o600)
            except OSError:
                pass
        else:
            from dotenv import set_key
            set_key(self.env_path, 'WEB_PASSWORD_HASH', new_hash)
        self.password_hash = new_hash
        keep = request.cookies.get('sid', '')
        self.sessions = {k: v for k, v in self.sessions.items() if k == keep}
        self.back('/settings', 'Пароль изменён.')


async def start_web(store, admins, send_message, env=None, env_path='.env'):
    """Start the panel if a password is configured. Never raises: the bot must keep running.

    Local mode (default): listens on 127.0.0.1 only.
    Cloud mode (WEB_HOST=0.0.0.0 + WEB_ALLOWED_HOSTS=your.domain): behind the host's HTTPS proxy.
    """
    env = os.environ if env is None else env
    if env.get('WEB_ENABLED', '1').strip() in {'0', 'false', 'no'}:
        return None
    folder = data_dir()
    hash_file = (folder / 'web_password.hash') if folder else None
    password_hash = ''
    if hash_file and hash_file.is_file():
        password_hash = hash_file.read_text().strip()  # set from the site: wins over the variable
    password_hash = password_hash or env.get('WEB_PASSWORD_HASH', '').strip()
    if not password_hash:
        logging.warning('Web admin is off: no password set. Run start.bat again or set_web_password.py.')
        return None
    cloud = env.get('AMVERA', '').strip() == '1'  # Amvera: public HTTPS domain in front of the app
    host = env.get('WEB_HOST', '').strip() or ('0.0.0.0' if cloud else '127.0.0.1')
    port = int(env.get('WEB_PORT') or (env.get('PORT') if cloud else '') or (80 if cloud else 8080))
    totp_secret = env.get('WEB_TOTP_SECRET', '').strip()
    extra_hosts = [h for h in env.get('WEB_ALLOWED_HOSTS', '').split(',') if h.strip()] or (['*'] if cloud else [])
    public = host not in {'127.0.0.1', 'localhost', '::1'}
    if public and not totp_secret and env.get('WEB_ALLOW_NO_2FA', '').strip() != '1':
        logging.error('Web admin NOT started: it would be reachable from the internet without a two-factor code. '
                      'Set WEB_TOTP_SECRET (see make_totp.py).')
        return None
    if public and not extra_hosts:
        logging.warning('WEB_HOST is public but WEB_ALLOWED_HOSTS is empty: the site will answer "Bad host".')
    flag = lambda name, default=False: (env.get(name, '').strip().lower() in {'1', 'true', 'yes'}) if env.get(name, '').strip() else default  # noqa: E731
    panel = WebAdmin(store, admins, send_message, password_hash, env.get('WEB_ADMIN_USER', 'admin').strip() or 'admin',
                     env_path=env_path, port=port, extra_hosts=extra_hosts, secure_cookies=flag('WEB_SECURE_COOKIES', cloud),
                     trust_proxy=flag('WEB_TRUST_PROXY', cloud), totp_secret=totp_secret, hash_file=hash_file)
    runner = web.AppRunner(panel.app, access_log=None)
    try:
        await runner.setup()
        await web.TCPSite(runner, host, port).start()
    except OSError as exc:
        logging.warning('Web admin could not start on port %s: %s. The bot keeps working.', port, exc)
        await runner.cleanup()
        return None
    logging.info('Web admin listening on %s:%s', host, port)
    print(f'Админ-панель на сайте: http://localhost:{port}' if not public else f'Админ-панель слушает порт {port} (доступ по домену из WEB_ALLOWED_HOSTS)')
    return runner
