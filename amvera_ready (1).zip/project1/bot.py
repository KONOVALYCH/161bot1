import asyncio
import logging
import os
from html import escape
from logging.handlers import RotatingFileHandler
from pathlib import Path
from urllib.parse import urlparse

from aiogram import BaseMiddleware, Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError, TelegramNetworkError, TelegramRetryAfter
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, FSInputFile, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiohttp import ClientConnectorError
from dotenv import load_dotenv

import backup
from documents import TemplateMissing, bank_document, cbr_document, data_dir, mvd_document, seed_templates
from storage import Storage
from web_admin import start_web

EVENTS_RETENTION_DAYS = int(os.getenv('EVENTS_RETENTION_DAYS', '30'))


class Form(StatesGroup):
    content = State()
    ticket = State()
    story = State()
    reply = State()
    admin_add_title = State()
    admin_add_body = State()
    admin_add_url = State()
    admin_service_title = State()
    admin_service_description = State()
    admin_service_price = State()
    admin_service_edit = State()


def keyboard(*rows):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, **({'url': value} if value.startswith('https://') else {'callback_data': value}))
         for label, value in row] for row in rows
    ])


BACK = keyboard([('◀️ В главное меню', 'home')])
CATEGORIES = {'bank': '🏦 Ограничения в банке', 'cbr': '🏛 Обращение в Банк России', 'other': '❓ Другой вопрос'}
NOTICE = (
    'Не указывайте ФИО, номера счетов и карт, паспортные данные, телефоны, '
    'пароли и коды. Сообщение сохраняется вместе с вашим Telegram ID и доступно администраторам. '
    'Отправляя текст, вы соглашаетесь на его обработку для ответа. '
    'Для удаления данных используйте /delete_me.'
)


DOC_CAPTION = (
    'Это образец документа (файл .docx). Заполните поля своими данными перед отправкой в банк или ведомство.'
)
BANK_SLUGS = {'sber', 'vtb', 'alfa', 'tbank', 'gazprom'}
SYSTEM_SLUGS = {
    'community', 'faq', 'faq_115', 'faq_161', 'faq_mvd', 'tickets', 'paid_services',
    'banks', 'stories', 'about', 'cbr', 'mvd',
}
BANK_DOC_LABELS = {
    'return': '📄 Заявление на возврат',
    'justification': '📄 Обоснование операции',
    'complaint': '📄 Досудебная претензия',
}
CBR_DOC_LABELS = {
    'exclude': '📄 Исключение из базы данных',
    'complaint': '📄 Жалоба на бездействие банка',
}


def money(value):
    return f'{int(value):,}'.replace(',', ' ') + ' ₽'


class PrivateActivity(BaseMiddleware):
    def __init__(self, store):
        self.store = store

    async def __call__(self, handler, event, data):
        message = event.message if isinstance(event, CallbackQuery) else event
        if not message or message.chat.type != 'private':
            if isinstance(event, CallbackQuery):
                await event.answer('Откройте личный чат с ботом.', show_alert=True)
            return
        await self.store.touch(event.from_user.id)
        return await handler(event, data)


class Throttle(BaseMiddleware):
    """Simple per-user cooldown so a fast-tapping or scripted client can't flood the bot/DB."""

    def __init__(self, min_interval=0.4):
        self.min_interval = min_interval
        self.last_seen = {}

    async def __call__(self, handler, event, data):
        uid = event.from_user.id if event.from_user else None
        if uid is not None:
            now = asyncio.get_event_loop().time()
            last = self.last_seen.get(uid, 0)
            if now - last < self.min_interval:
                if isinstance(event, CallbackQuery):
                    await event.answer()
                return
            self.last_seen[uid] = now
        return await handler(event, data)


def build_dispatcher(store, admins, community):
    dp = Dispatcher()
    dp.message.outer_middleware(Throttle())
    dp.callback_query.outer_middleware(Throttle())
    dp.message.outer_middleware(PrivateActivity(store))
    dp.callback_query.outer_middleware(PrivateActivity(store))

    async def paid_services_view(message, uid):
        services = await store.rows('SELECT * FROM paid_services WHERE active=1 ORDER BY position, id')
        rows = [[(f'{row["title"]} — {money(row["price"])}', f'service:{row["id"]}') ] for row in services]
        rows.append([('🏠 Главное меню', 'home')])
        text = ('<b>💳 Платные услуги</b>\n\nВыберите услугу, чтобы посмотреть описание и стоимость.'
                if services else '<b>💳 Платные услуги</b>\n\nСейчас услуги не опубликованы.')
        await message.answer(text, reply_markup=keyboard(*rows))

    async def service_view(message, service_id):
        service = await store.one('SELECT * FROM paid_services WHERE id=? AND active=1', (service_id,))
        if not service:
            await message.answer('Услуга недоступна или удалена.', reply_markup=keyboard([('◀️ Назад', 'paid_services')]))
            return
        text = (f'<b>{escape(service["title"])}</b>\n\n'
                f'{escape(service["description"] or "Описание не указано.")}\n\n'
                f'<b>Стоимость: {money(service["price"])}</b>')
        await message.answer(text, reply_markup=keyboard(
            [('📩 Заказать услугу', f'service_order:{service_id}')],
            [('◀️ К списку услуг', 'paid_services')],
            [('🏠 Главное меню', 'home')],
        ))

    async def section_view(message, uid, section, rows=None):
        rows = list(rows or [])
        slug = section["slug"]

        if slug == 'paid_services':
            await paid_services_view(message, uid)
            return

        # User menu is deliberately simple: one generic "Банки" hub with document
        # types inside. Individual bank entries remain in the DB for compatibility,
        # but are no longer shown as child buttons of the hub.
        if slug != 'banks':
            children = await store.rows(
                "SELECT * FROM sections WHERE parent_id=? ORDER BY position, id",
                (section['id'],),
            )
            for child in children:
                rows.append([(child['title'], f'section:{child["id"]}')])

        if slug == 'community':
            if section['url'] or community:
                rows.append([('🔗 Получить ссылку на чат', 'community_link')])
        elif slug == 'tickets':
            rows.extend([[('📝 Заказать обращение', 'new_ticket')], [('📂 Мои обращения', 'my_tickets:0')]])
        elif slug == 'banks' or slug in BANK_SLUGS:
            rows.extend([[(label, f'doc:bank:{key}')] for key, label in BANK_DOC_LABELS.items()])
        elif slug == 'cbr':
            rows.extend([[(label, f'doc:cbr:{key}')] for key, label in CBR_DOC_LABELS.items()])
        elif slug == 'about':
            rows.append([('🌐 Сайт Банка России', 'https://www.cbr.ru/')])

        if slug != 'community' and section['url']:
            rows.append([('🌐 Открыть ссылку', section['url'])])

        # Admin controls are intentionally kept OUT of normal menu navigation.
        # Admin enters the dedicated panel first, then edits menu items there.
        if uid in admins and slug == 'home':
            rows.append([('⚙️ Войти в админ-панель', 'admin')])

        if section['parent_id']:
            rows.append([('◀️ Назад', f'section:{section["parent_id"]}')])
        if slug != 'home':
            rows.append([('🏠 Главное меню', 'home')])

        text = f'<b>{escape(section["title"])}</b>\n\n{escape(section["body"])}'
        if slug == 'about':
            text += '\n\n' + NOTICE
        if slug == 'community' and not (section['url'] or community):
            text += '\n\nЧат пока не настроен. Администратор может задать URL в этом разделе.'
        if slug == 'mvd':
            try:
                filename, path = mvd_document()
            except TemplateMissing:
                logging.error('MVD template missing on disk')
                await message.answer(
                    text + '\n\n⚠️ Файл шаблона временно недоступен. Администратор уже уведомлён.',
                    reply_markup=keyboard(*rows),
                )
                return
            await message.answer_document(
                FSInputFile(path, filename=filename),
                caption=text, reply_markup=keyboard(*rows),
            )
            return
        await message.answer(text, reply_markup=keyboard(*rows))

    async def send_template_doc(message, filename, path):
        await message.answer_document(
            FSInputFile(path, filename=filename),
            caption=DOC_CAPTION, reply_markup=BACK,
        )

    async def notify(bot, text, markup=None):
        for admin in admins:
            try:
                await bot.send_message(admin, text, reply_markup=markup)
            except TelegramAPIError:
                logging.warning('Admin notification failed for %s', admin)

    @dp.message(CommandStart())
    @dp.message(Command('cancel'))
    async def start(message: Message, state: FSMContext):
        await state.clear()
        await section_view(message, message.from_user.id, await store.one("SELECT * FROM sections WHERE slug='home'"))

    @dp.message(Command('admin'))
    async def admin_command(message: Message, state: FSMContext):
        await state.clear()
        if message.from_user.id not in admins:
            await message.answer('Доступ ограничен.')
            return
        await admin_panel(message)

    async def admin_menu_panel(message):
        sections = await store.rows('SELECT * FROM sections ORDER BY position, id')
        by_parent = {}
        for row in sections:
            by_parent.setdefault(row['parent_id'], []).append(row)

        lines = []
        buttons = []

        def walk(parent_id, depth=0):
            for row in by_parent.get(parent_id, []):
                prefix = '— ' * depth
                lines.append(f'{prefix}{escape(row["title"])}  <code>#{row["id"]}</code>')
                buttons.append([(f'{prefix}✏️ {row["title"]}', f'admin_edit:{row["id"]}')])
                walk(row['id'], depth + 1)

        walk(None)
        text = '<b>🛠 Управление меню</b>\n\n' + (\
            '\n'.join(lines) if lines else 'Меню пока пустое.') + \
            '\n\nЗдесь можно создавать свои разделы и подразделы, менять заголовки, тексты, ссылки, порядок и удалять ненужные пункты.'
        buttons.extend([
            [('➕ Добавить пункт меню', 'admin_add_root')],
            [('💳 Управление платными услугами', 'admin_services')],
            [('🏠 В админ-панель', 'admin'), ('🏠 Главное меню', 'home')],
        ])
        await message.answer(text, reply_markup=keyboard(*buttons))

    async def admin_edit_panel(message, section_id):
        section = await store.one('SELECT * FROM sections WHERE id=?', (section_id,))
        if not section:
            await message.answer('Раздел не найден.', reply_markup=keyboard([('🛠 Управление меню', 'admin_menu')]))
            return
        children = await store.one('SELECT id FROM sections WHERE parent_id=? LIMIT 1', (section_id,))
        delete_label = '🗑 Удалить' if not children and section['slug'] != 'home' else '🗑 Удаление недоступно'
        parent_title = 'Главное меню'
        if section['parent_id']:
            parent = await store.one('SELECT title FROM sections WHERE id=?', (section['parent_id'],))
            parent_title = parent['title'] if parent else '—'
        await message.answer(
            f'<b>Редактирование пункта</b>\n\n'
            f'<b>#{section["id"]}</b> {escape(section["title"])}\n'
            f'Родитель: {escape(parent_title)}\n'
            f'URL: {escape(section["url"] or "—")}',
            reply_markup=keyboard(
                [('✏️ Изменить заголовок', f'a_title:{section_id}')],
                [('✏️ Изменить текст', f'a_body:{section_id}')],
                [('🔗 Изменить URL', f'a_url:{section_id}')],
                [('➕ Добавить подраздел', f'a_add:{section_id}')],
                [('⬆️ Выше', f'a_up:{section_id}'), ('⬇️ Ниже', f'a_down:{section_id}')],
                [(delete_label, f'a_delete:{section_id}')],
                [('◀️ К списку меню', 'admin_menu'), ('⚙️ В админ-панель', 'admin')],
            ),
        )

    async def admin_add_parent_picker(message):
        sections = await store.rows('SELECT * FROM sections ORDER BY position, id')
        rows = [[('🏠 Главное меню', 'a_newparent:0')]]
        for row in sections:
            if row['slug'] == 'home':
                continue
            rows.append([(f'#{row["id"]} {row["title"]}', f'a_newparent:{row["id"]}')])
        rows.append([('❌ Отмена', 'admin_menu')])
        await message.answer(
            '<b>Новый пункт меню</b>\n\nВыберите, где создать новый пункт:',
            reply_markup=keyboard(*rows),
        )

    async def admin_services_panel(message):
        services = await store.rows('SELECT * FROM paid_services ORDER BY position, id')
        buttons = []
        lines = []
        for row in services:
            status = '✅' if row['active'] else '⛔'
            lines.append(f'{status} <b>#{row["id"]}</b> {escape(row["title"])} — <b>{money(row["price"])}</b>')
            buttons.append([(f'✏️ {row["title"]}', f'admin_service_edit:{row["id"]}')])
        text = '<b>💳 Управление платными услугами</b>\n\n' + ('\n'.join(lines) if lines else 'Услуг пока нет.') + '\n\nДобавление, редактирование цены и описания, публикация/скрытие, порядок и удаление.'
        buttons.extend([
            [('➕ Добавить услугу', 'admin_service_add')],
            [('◀️ В админ-панель', 'admin'), ('🏠 Главное меню', 'home')],
        ])
        await message.answer(text, reply_markup=keyboard(*buttons))

    async def admin_service_edit_panel(message, service_id):
        service = await store.one('SELECT * FROM paid_services WHERE id=?', (service_id,))
        if not service:
            await message.answer('Услуга не найдена.', reply_markup=keyboard([('💳 Управление услугами', 'admin_services')]))
            return
        status = '✅ Опубликована' if service['active'] else '⛔ Скрыта'
        await message.answer(
            f'<b>Редактирование услуги</b>\n\n<b>#{service["id"]}</b> {escape(service["title"])}\n'
            f'Цена: <b>{money(service["price"])}</b>\nСтатус: {status}\n\n{escape(service["description"] or "Описание не указано.")}',
            reply_markup=keyboard(
                [('✏️ Изменить название', f'sa_title:{service_id}')],
                [('✏️ Изменить описание', f'sa_desc:{service_id}')],
                [('💰 Изменить цену', f'sa_price:{service_id}')],
                [('🔁 ' + ('Скрыть услугу' if service['active'] else 'Опубликовать услугу'), f'sa_toggle:{service_id}')],
                [('⬆️ Выше', f'sa_up:{service_id}'), ('⬇️ Ниже', f'sa_down:{service_id}')],
                [('🗑 Удалить', f'sa_delete:{service_id}')],
                [('◀️ К списку услуг', 'admin_services'), ('⚙️ В админ-панель', 'admin')],
            ),
        )

    async def admin_panel(message):
        s = await store.stats()
        clicks = await store.click_stats()
        ranking = [r for r in clicks if r['name'].startswith('click:section:')][:15]
        sections = '\n'.join(f'{escape(r["name"][len("click:section:"):])}: {r["n"]}' for r in ranking) or 'Нет данных'
        frequent = '\n'.join(f'{escape(r["name"][6:])}: {r["n"]}' for r in clicks[:10]) or 'Нет данных'
        await message.answer(
            '<b>Панель администратора</b>\n\n'
            f'Пользователи: <b>{s["users"]}</b>\nНовые за 7 дней: {s["new_users"]}\n'
            f'Активные за 24 часа: {s["active"]}\n\n'
            f'Обращения: {s["tickets"]}\nОткрытые: {s["open_tickets"]}\n'
            f'Закрытые: {s["closed_tickets"]}\nДоставленные ответы: {s["replies"]}\n\n'
            f'Истории на модерации: {s["pending"]}\nОпубликованы: {s["published"]}\n'
            'Общие показатели выше включают администраторов.\n\n'
            f'Клики за 7 дней, без администраторов:\nРазделы (топ-15):\n{sections}\n\nЧастые кнопки:\n{frequent}\n\n'
            'Запрос ссылки чата не означает переход или вступление. Нажатия прямых URL-кнопок других разделов не учитываются.',
            reply_markup=keyboard(
                [('🛠 Управление меню', 'admin_menu')],
                [('💳 Управление платными услугами', 'admin_services')],
                [('➕ Добавить пункт меню', 'admin_add_root')],
                [('📨 Открытые обращения', 'a_tickets:0')],
                [('📖 Модерация историй', 'a_stories:0')],
                [('🔄 Обновить статистику', 'admin'), ('🏠 Главное меню', 'home')],
            ),
        )

    @dp.message(Command('delete_me'))
    async def delete_prompt(message: Message, state: FSMContext):
        await state.clear()
        await message.answer(
            'Удалить ваши обращения, ответы, истории (включая опубликованные) и профиль из базы бота? '
            'Копии сообщений в Telegram и резервных копиях автоматически не удаляются.',
            reply_markup=keyboard([('🗑 Да, удалить данные', 'delete_confirm')], [('❌ Отмена', 'home')]),
        )

    @dp.callback_query()
    async def callback(query: CallbackQuery, state: FSMContext, bot: Bot):
        action = query.data or ''
        uid = query.from_user.id
        message = query.message
        # Admin-only action namespaces: exact 'admin', and anything prefixed 'admin_', 'a_', or 'sa_'.
        # (Must be a broad prefix check — 'admin_menu' and 'admin_edit:' do NOT start with 'a_',
        # only with 'admin_', so a narrower check here would let non-admins view menu internals.)
        if action == 'admin' or action.startswith(('admin_', 'a_', 'sa_')):
            if uid not in admins:
                await query.answer('Доступ ограничен.', show_alert=True)
                return
        await query.answer()
        await state.clear()
        section = None
        if action in {'home', 'community', 'tickets', 'about', 'paid_services'} or action.startswith('stories:'):
            section = await store.one('SELECT * FROM sections WHERE slug=?', (action.split(':')[0],))
        elif action.startswith('section:'):
            section = await store.one('SELECT * FROM sections WHERE id=?', (action.split(':', 1)[1],))
            if not section:
                return
            if section['slug'] == 'stories':
                action = 'stories:0'
        if uid not in admins:
            names = {'new_ticket': '📝 Создать обращение', 'new_story': '✍️ Поделиться историей', 'my_tickets': '📂 Мои обращения', 'delete_confirm': '🗑 Удалить данные'}
            name = None
            if section:
                name = f'section:{section["id"]} {section["title"]}'
            elif action.split(':')[0] in names:
                name = names[action.split(':')[0]]
            elif action.startswith('category:') and action.split(':')[1] in CATEGORIES:
                name = 'Тема: ' + CATEGORIES[action.split(':')[1]]
            elif action.startswith('service:'):
                service = await store.one('SELECT title FROM paid_services WHERE id=?', (action.split(':', 1)[1],))
                if service:
                    name = f'Услуга: {service["title"]}'
            elif action.startswith('doc:'):
                parts = action.split(':')
                if parts[1] == 'bank' and len(parts) == 4 and parts[2] in BANK_SLUGS and parts[3] in BANK_DOC_LABELS:
                    name = f'Файл: {parts[2]} / {BANK_DOC_LABELS[parts[3]]}'
                elif parts[1] == 'cbr' and len(parts) == 3 and parts[2] in CBR_DOC_LABELS:
                    name = f'Файл: ЦБ / {CBR_DOC_LABELS[parts[2]]}'
            if name:
                await store.event('click:' + name)
        if section and not action.startswith('stories:'):
            await section_view(message, uid, section)
            return
        if action == 'admin_menu':
            await admin_menu_panel(message)
            return
        if action.startswith('admin_edit:'):
            await admin_edit_panel(message, int(action.split(':', 1)[1]))
            return
        if action == 'admin_add_root':
            await admin_add_parent_picker(message)
            return
        if action.startswith('a_newparent:'):
            parent_id = int(action.split(':', 1)[1])
            if parent_id and not await store.one('SELECT id FROM sections WHERE id=?', (parent_id,)):
                await message.answer('Родительский раздел не найден.')
                return
            await state.set_state(Form.admin_add_title)
            await state.update_data(parent_id=parent_id or None)
            await message.answer('Введите название нового пункта меню (до 80 символов). Отмена: /cancel', reply_markup=BACK)
            return
        if action.startswith('a_add:'):
            parent_id = int(action.split(':', 1)[1])
            if not await store.one('SELECT id FROM sections WHERE id=?', (parent_id,)):
                return
            await state.set_state(Form.admin_add_title)
            await state.update_data(parent_id=parent_id)
            await message.answer('Введите название нового подраздела (до 80 символов). Отмена: /cancel', reply_markup=BACK)
            return
        if action.startswith(('a_up:', 'a_down:')):
            sid = int(action.split(':', 1)[1])
            section = await store.one('SELECT * FROM sections WHERE id=?', (sid,))
            if not section:
                return
            direction = -1 if action.startswith('a_up:') else 1
            neighbour = None
            if direction < 0:
                neighbour = await store.one(
                    'SELECT * FROM sections WHERE parent_id IS ? AND (position < ?) ORDER BY position DESC, id DESC LIMIT 1',
                    (section['parent_id'], section['position']),
                )
            else:
                neighbour = await store.one(
                    'SELECT * FROM sections WHERE parent_id IS ? AND (position > ?) ORDER BY position ASC, id ASC LIMIT 1',
                    (section['parent_id'], section['position']),
                )
            if neighbour:
                await store.db.execute('UPDATE sections SET position=? WHERE id=?', (neighbour['position'], section['id']))
                await store.db.execute('UPDATE sections SET position=? WHERE id=?', (section['position'], neighbour['id']))
                await store.db.commit()
            await admin_edit_panel(message, sid)
            return
        if action.startswith('a_delete:'):
            sid = int(action.split(':', 1)[1])
            section = await store.one('SELECT * FROM sections WHERE id=?', (sid,))
            if not section:
                return
            if section['slug'] == 'home':
                await message.answer('Главное меню удалить нельзя.', reply_markup=keyboard([('🛠 Управление меню', 'admin_menu')]))
                return
            child = await store.one('SELECT id FROM sections WHERE parent_id=? LIMIT 1', (sid,))
            if child:
                await message.answer('Сначала удалите или перенесите подразделы этого пункта.', reply_markup=keyboard([('◀️ Назад', f'admin_edit:{sid}')]))
                return
            warning = ''
            if section['slug'] in SYSTEM_SLUGS:
                warning = (
                    '\n\n⚠️ Это системный раздел: с ним связано отдельное поведение бота '
                    '(документы, обращения, платные услуги или FAQ). После удаления связанная '
                    'функциональность перестанет отображаться в меню.'
                )
            await message.answer(
                f'Удалить пункт «{escape(section["title"])}»? Отменить это действие нельзя.{warning}',
                reply_markup=keyboard(
                    [('🗑 Да, удалить', f'a_delete_confirm:{sid}')],
                    [('❌ Отмена', f'admin_edit:{sid}')],
                ),
            )
            return
        if action.startswith('a_delete_confirm:'):
            sid = int(action.split(':', 1)[1])
            section = await store.one('SELECT * FROM sections WHERE id=?', (sid,))
            if not section:
                return
            if section['slug'] == 'home':
                return
            child = await store.one('SELECT id FROM sections WHERE parent_id=? LIMIT 1', (sid,))
            if child:
                await message.answer('Сначала удалите или перенесите подразделы этого пункта.', reply_markup=keyboard([('◀️ Назад', f'admin_edit:{sid}')]))
                return
            await store.execute('DELETE FROM sections WHERE id=?', (sid,))
            await message.answer('Пункт меню удалён.', reply_markup=keyboard([('🛠 Управление меню', 'admin_menu'), ('⚙️ В админ-панель', 'admin')]))
            return
        if action.startswith('doc:'):
            parts = action.split(':')
            try:
                if parts[1] == 'bank' and len(parts) == 3 and parts[2] in BANK_DOC_LABELS:
                    filename, path = bank_document(parts[2], None)
                elif parts[1] == 'bank' and len(parts) == 4 and parts[2] in BANK_SLUGS and parts[3] in BANK_DOC_LABELS:
                    # Backward compatibility with old callback buttons.
                    filename, path = bank_document(parts[3], parts[2])
                elif parts[1] == 'cbr' and len(parts) == 3 and parts[2] in CBR_DOC_LABELS:
                    filename, path = cbr_document(parts[2])
                else:
                    return
            except ValueError:
                return
            except TemplateMissing:
                logging.error('Template missing on disk for action=%s', action)
                await message.answer(
                    '⚠️ Файл шаблона временно недоступен. Попробуйте позже или сообщите администратору.',
                    reply_markup=BACK,
                )
                return
            await send_template_doc(message, filename, path)
            return
        if action == 'community_link':
            destination = await store.one("SELECT url FROM sections WHERE slug='community'")
            link = destination['url'] or community
            if not link:
                await message.answer('Чат пока не настроен.', reply_markup=BACK)
                return
            if uid not in admins:
                await store.event('click:Запрос ссылки чата')
            await message.answer('Ссылка на чат. Запрос ссылки не означает вступление.',
                                 reply_markup=keyboard([('💬 Перейти в чат', link)], [('◀️ Назад', 'community')]))
            return
        if action == 'admin_services':
            await admin_services_panel(message)
            return
        if action == 'admin_service_add':
            await state.set_state(Form.admin_service_title)
            await message.answer('Введите название услуги (до 100 символов). Отмена: /cancel', reply_markup=keyboard([('❌ Отмена', 'admin_services')]))
            return
        if action.startswith('admin_service_edit:'):
            await admin_service_edit_panel(message, int(action.split(':', 1)[1]))
            return
        if action.startswith('sa_title:') or action.startswith('sa_desc:') or action.startswith('sa_price:'):
            operation, sid = action.split(':', 1)
            if not await store.one('SELECT id FROM paid_services WHERE id=?', (sid,)):
                return
            await state.set_state(Form.admin_service_edit)
            await state.update_data(service_id=int(sid), operation=operation)
            prompt = ('Введите новое название услуги (до 100 символов).' if operation == 'sa_title'
                      else 'Введите новое описание (до 1500 символов).' if operation == 'sa_desc'
                      else 'Введите цену целым числом в рублях, например 5000.')
            await message.answer(prompt, reply_markup=keyboard([('❌ Отмена', f'admin_service_edit:{sid}')]))
            return
        if action.startswith('sa_toggle:'):
            sid = int(action.split(':', 1)[1])
            await store.execute('UPDATE paid_services SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?', (sid,))
            await admin_service_edit_panel(message, sid)
            return
        if action.startswith('sa_up:') or action.startswith('sa_down:'):
            sid = int(action.split(':', 1)[1])
            service = await store.one('SELECT * FROM paid_services WHERE id=?', (sid,))
            if not service:
                return
            if action.startswith('sa_up:'):
                neighbour = await store.one('SELECT * FROM paid_services WHERE position < ? ORDER BY position DESC, id DESC LIMIT 1', (service['position'],))
            else:
                neighbour = await store.one('SELECT * FROM paid_services WHERE position > ? ORDER BY position ASC, id ASC LIMIT 1', (service['position'],))
            if neighbour:
                await store.db.execute('UPDATE paid_services SET position=? WHERE id=?', (neighbour['position'], sid))
                await store.db.execute('UPDATE paid_services SET position=? WHERE id=?', (service['position'], neighbour['id']))
                await store.db.commit()
            await admin_service_edit_panel(message, sid)
            return
        if action.startswith('sa_delete:'):
            sid = int(action.split(':', 1)[1])
            service = await store.one('SELECT * FROM paid_services WHERE id=?', (sid,))
            if not service:
                return
            await message.answer(
                f'Удалить услугу «{escape(service["title"])}»? Отменить это действие нельзя.',
                reply_markup=keyboard(
                    [('🗑 Да, удалить', f'sa_delete_confirm:{sid}')],
                    [('❌ Отмена', f'admin_service_edit:{sid}')],
                ),
            )
            return
        if action.startswith('sa_delete_confirm:'):
            sid = int(action.split(':', 1)[1])
            await store.execute('DELETE FROM paid_services WHERE id=?', (sid,))
            await message.answer('Услуга удалена.', reply_markup=keyboard([('💳 Управление услугами', 'admin_services'), ('⚙️ В админ-панель', 'admin')]))
            return
        if action.startswith('service:'):
            await service_view(message, int(action.split(':', 1)[1]))
            return
        if action.startswith('service_order:'):
            sid = int(action.split(':', 1)[1])
            service = await store.one('SELECT * FROM paid_services WHERE id=? AND active=1', (sid,))
            if not service:
                await message.answer('Услуга недоступна.', reply_markup=keyboard([('💳 Платные услуги', 'paid_services')]))
                return
            await state.set_state(Form.ticket)
            await state.update_data(category=f'Платная услуга: {service["title"]}', service_id=sid)
            await message.answer(
                f'<b>Заказ услуги: {escape(service["title"])}</b>\n\nСтоимость: <b>{money(service["price"])}</b>\n\n'
                'Опишите, что именно вам нужно сделать. Администратор свяжется с вами по обращению.\n\n'
                '💳 Оплата через бота не производится: сумма и способ оплаты обсуждаются с администратором '
                'после того, как он свяжется с вами. Отправка этой заявки не списывает деньги.\n\n'
                + NOTICE + '\n\nОтмена: /cancel',
                reply_markup=BACK,
            )
            return

        if action.startswith(('a_title:', 'a_body:', 'a_url:')):
            operation, sid = action.split(':', 1)
            if not await store.one('SELECT id FROM sections WHERE id=?', (sid,)):
                return
            await state.set_state(Form.content)
            await state.update_data(operation=operation, section_id=sid)
            prompt = 'Введите текст (до 2500 символов).' if operation == 'a_body' else 'Введите заголовок (до 80 символов).'
            if operation == 'a_url':
                prompt = 'Введите HTTPS URL (до 2048 символов) или - для очистки. Отмена: /cancel'
            await message.answer(prompt, reply_markup=BACK)
            return
        if action == 'new_ticket':
            await message.answer(
                '<b>📝 Заказать обращение</b>\n\n'
                'Эта услуга — подготовка индивидуального обращения под вашу ситуацию. Обращение формируется '
                'на основе того, что вы опишете, и направляется в банк или Банк России.\n\n'
                'Выберите тему:',
                reply_markup=keyboard(
                    *[[(label, f'category:{key}')] for key, label in CATEGORIES.items()], [('🏠 Главное меню', 'home')]))
        elif action.startswith('category:'):
            category = action.split(':')[1]
            if category not in CATEGORIES:
                return
            await state.set_state(Form.ticket)
            await state.update_data(category=CATEGORIES[category])
            await message.answer(
                '<b>Опишите ситуацию одним сообщением</b>\nУкажите банк, дату ограничения, '
                'ответ банка и что уже предприняли. От 30 до 2500 символов.\n\n' + NOTICE + '\n\nОтмена: /cancel', reply_markup=BACK)
        elif action.startswith('my_tickets:'):
            offset = max(0, int(action.split(':')[1]))
            rows = await store.rows('SELECT * FROM tickets WHERE user_id=? ORDER BY id DESC LIMIT 6 OFFSET ?', (uid, offset))
            for row in rows[:5]:
                replies = await store.rows('SELECT body, delivered FROM replies WHERE ticket_id=? ORDER BY id', (row['id'],))
                await message.answer(f'<b>Обращение №{row["id"]}</b> · {"Открыто" if row["status"] == "open" else "Закрыто"}\n'
                                     f'{escape(row["category"])}\n\n{escape(row["body"])}')
                for reply in replies:
                    await message.answer(f'<b>Ответ по №{row["id"]}</b>\n{escape(reply["body"])}')
            await message.answer('Ваши обращения.' if rows else 'У вас пока нет обращений.', reply_markup=keyboard(
                *([[('➡️ Следующие', f'my_tickets:{offset + 5}')]] if len(rows) > 5 else []), [('🏠 Главное меню', 'home')]))
        elif action.startswith('stories:'):
            offset = max(0, int(action.split(':')[1]))
            rows = await store.rows("SELECT * FROM stories WHERE status='published' ORDER BY id DESC LIMIT 2 OFFSET ?", (offset,))
            if rows:
                await message.answer(f'<b>История №{rows[0]["id"]}</b>\n<i>Личный опыт участника; результат не гарантирован.</i>\n\n{escape(rows[0]["body"])}')
            await section_view(message, uid, section,
                ([[('➡️ Следующая история', f'stories:{offset + 1}')]] if len(rows) > 1 else []) + [[('✍️ Поделиться историей', 'new_story')]])
        elif action == 'new_story':
            await state.set_state(Form.story)
            await message.answer(
                '<b>Поделитесь опытом разблокировки</b>\nНапишите: какая была проблема, куда обращались, '
                'какие шаги помогли, сроки и результат. От 30 до 2500 символов.\n\n'
                'Текст после проверки будет опубликован без ссылки на профиль. Не включайте сведения, '
                'по которым можно определить вас или других людей. Отправляя историю, вы соглашаетесь с публикацией.\n\n'
                + NOTICE + '\n\nОтмена: /cancel', reply_markup=BACK)
        elif action == 'admin':
            await admin_panel(message)
        elif action.startswith('a_tickets:') or action.startswith('a_stories:'):
            tickets = action.startswith('a_tickets:')
            offset = max(0, int(action.split(':')[1]))
            table, status = ('tickets', 'open') if tickets else ('stories', 'pending')
            rows = await store.rows(f'SELECT * FROM {table} WHERE status=? ORDER BY id LIMIT 6 OFFSET ?', (status, offset))
            for row in rows[:5]:
                rid = row['id']
                markup = keyboard([('✍️ Ответить', f'a_reply:{rid}'), ('✅ Закрыть', f'a_close:{rid}')]) if tickets else keyboard(
                    [('✅ Опубликовать', f'a_publish:{rid}'), ('🚫 Отклонить', f'a_reject:{rid}')])
                await message.answer(f'<b>{"Обращение" if tickets else "История"} №{rid}</b>\n'
                                     f'{row["created_at"]} UTC\n\n{escape(row["body"])}', reply_markup=markup)
            await message.answer('Очередь обработки.' if rows else 'Очередь пуста.', reply_markup=keyboard(
                *([[('➡️ Далее', f'{action.split(":")[0]}:{offset + 5}')]] if len(rows) > 5 else []), [('⚙️ Панель администратора', 'admin')]))
        elif action.startswith('a_reply:'):
            rid = int(action.split(':')[1])
            row = await store.one("SELECT id FROM tickets WHERE id=? AND status='open'", (rid,))
            if not row:
                await message.answer('Обращение закрыто или удалено.')
                return
            await state.set_state(Form.reply)
            await state.update_data(ticket_id=rid)
            await message.answer(f'Введите ответ по обращению №{rid}, до 2500 символов. Отмена: /cancel')
        elif action.startswith('a_close:'):
            rid = int(action.split(':')[1])
            await store.execute("UPDATE tickets SET status='closed' WHERE id=?", (rid,))
            await message.answer(f'Обращение №{rid} закрыто.', reply_markup=keyboard([('⚙️ К панели', 'admin')]))
        elif action.startswith('a_publish:') or action.startswith('a_reject:'):
            rid = int(action.split(':')[1])
            status = 'published' if action.startswith('a_publish:') else 'rejected'
            row = await store.one("UPDATE stories SET status=?, moderator_id=? WHERE id=? AND status='pending' RETURNING id", (status, uid, rid))
            await store.db.commit()
            await message.answer(('История опубликована.' if status == 'published' else 'История отклонена.') if row else 'История уже обработана или удалена.')
        elif action == 'delete_confirm':
            # One transaction prevents partially deleted profiles.
            await store.db.execute('DELETE FROM replies WHERE ticket_id IN (SELECT id FROM tickets WHERE user_id=?)', (uid,))
            await store.db.execute('DELETE FROM tickets WHERE user_id=?', (uid,))
            await store.db.execute('DELETE FROM stories WHERE user_id=?', (uid,))
            await store.db.execute('DELETE FROM users WHERE id=?', (uid,))
            await store.db.commit()
            await message.answer('Ваши данные удалены из базы бота. /start создаст новый профиль.')

    @dp.message(Form.admin_service_title)
    async def admin_service_title(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear(); await message.answer('Доступ ограничен.'); return
        text = (message.text or '').strip()
        if not 1 <= len(text) <= 100:
            await message.answer('Название должно быть от 1 до 100 символов. Отмена: /cancel'); return
        await state.update_data(title=text)
        await state.set_state(Form.admin_service_description)
        await message.answer('Введите описание услуги (до 1500 символов) или - чтобы оставить пустым.')

    @dp.message(Form.admin_service_description)
    async def admin_service_description(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear(); await message.answer('Доступ ограничен.'); return
        text=(message.text or '').strip()
        if text == '-': text=''
        if len(text) > 1500:
            await message.answer('Описание не должно превышать 1500 символов. Отмена: /cancel'); return
        await state.update_data(description=text)
        await state.set_state(Form.admin_service_price)
        await message.answer('Введите цену целым числом в рублях, например 5000.')

    @dp.message(Form.admin_service_price)
    async def admin_service_price(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear(); await message.answer('Доступ ограничен.'); return
        raw=(message.text or '').strip().replace(' ','').replace('₽','')
        try: price=int(raw)
        except ValueError: price=-1
        if price < 0 or price > 10_000_000:
            await message.answer('Цена должна быть целым числом от 0 до 10 000 000 рублей. Отмена: /cancel'); return
        data=await state.get_data()
        maxrow=await store.one('SELECT COALESCE(MAX(position), -1) AS p FROM paid_services')
        await store.execute('INSERT INTO paid_services(title,description,price,position,active) VALUES (?,?,?,?,1)', (data['title'],data.get('description',''),price,int(maxrow['p'])+1))
        await state.clear()
        await message.answer('Услуга добавлена и опубликована.', reply_markup=keyboard([('💳 Управление услугами','admin_services'),('⚙️ В админ-панель','admin')]))

    @dp.message(Form.admin_service_edit)
    async def admin_service_edit(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear(); await message.answer('Доступ ограничен.'); return
        data=await state.get_data(); sid=int(data.get('service_id',0)); operation=data.get('operation')
        service=await store.one('SELECT * FROM paid_services WHERE id=?',(sid,))
        if not service:
            await state.clear(); await message.answer('Услуга не найдена.', reply_markup=keyboard([('💳 Управление услугами','admin_services')]))
            return
        text=(message.text or '').strip()
        if operation=='sa_title':
            if not 1 <= len(text) <= 100:
                await message.answer('Название должно быть от 1 до 100 символов.'); return
            await store.execute('UPDATE paid_services SET title=? WHERE id=?',(text,sid))
        elif operation=='sa_desc':
            if text=='-': text=''
            if len(text)>1500:
                await message.answer('Описание не должно превышать 1500 символов.'); return
            await store.execute('UPDATE paid_services SET description=? WHERE id=?',(text,sid))
        elif operation=='sa_price':
            raw=text.replace(' ','').replace('₽','')
            try: price=int(raw)
            except ValueError: price=-1
            if price < 0 or price > 10_000_000:
                await message.answer('Цена должна быть целым числом от 0 до 10 000 000 рублей.'); return
            await store.execute('UPDATE paid_services SET price=? WHERE id=?',(price,sid))
        else:
            await state.clear(); return
        await state.clear(); await admin_service_edit_panel(message,sid)

    @dp.message(Form.admin_add_title)
    async def admin_add_title(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear()
            await message.answer('Доступ ограничен.')
            return
        text = (message.text or '').strip()
        if not 1 <= len(text) <= 80:
            await message.answer('Название должно быть от 1 до 80 символов. Отмена: /cancel')
            return
        await state.update_data(title=text)
        await state.set_state(Form.admin_add_body)
        await message.answer('Введите текст пункта (до 2500 символов). Можно оставить пустым: -')

    @dp.message(Form.admin_add_body)
    async def admin_add_body(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear()
            await message.answer('Доступ ограничен.')
            return
        text = (message.text or '').strip()
        if text == '-':
            text = ''
        if len(text) > 2500:
            await message.answer('Текст не должен превышать 2500 символов. Отмена: /cancel')
            return
        await state.update_data(body=text)
        await state.set_state(Form.admin_add_url)
        await message.answer('Введите HTTPS-ссылку (до 2048 символов) или - если ссылка не нужна.')

    @dp.message(Form.admin_add_url)
    async def admin_add_url(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear()
            await message.answer('Доступ ограничен.')
            return
        text = (message.text or '').strip()
        if text == '-':
            text = ''
        if text:
            try:
                url = urlparse(text)
                valid = text.startswith('https://') and bool(url.netloc) and bool(url.hostname) and not any(c.isspace() or ord(c) < 32 for c in text)
                url.port
            except ValueError:
                valid = False
            if not valid:
                await message.answer('Нужен корректный HTTPS URL или -. Отмена: /cancel')
                return
        data = await state.get_data()
        parent_id = data.get('parent_id')
        maxrow = await store.one('SELECT COALESCE(MAX(position), -1) AS p FROM sections WHERE parent_id IS ?', (parent_id,))
        position = int(maxrow['p']) + 1
        await store.execute(
            'INSERT INTO sections(parent_id,title,body,position,url) VALUES (?,?,?,?,?)',
            (parent_id, data['title'], data.get('body', ''), position, text),
        )
        await state.clear()
        await message.answer('Пункт меню создан.', reply_markup=keyboard([('🛠 Управление меню', 'admin_menu'), ('⚙️ В админ-панель', 'admin')]))

    @dp.message(Form.content)
    async def save_content(message: Message, state: FSMContext):
        if message.from_user.id not in admins:
            await state.clear()
            await message.answer('Доступ ограничен.')
            return
        data = await state.get_data()
        text = (message.text or '').strip()
        operation = data.get('operation')
        if operation not in {'a_title', 'a_body', 'a_url'}:
            await state.clear()
            return
        limit = 2048 if operation == 'a_url' else 2500 if operation == 'a_body' else 80
        if not 1 <= len(text) <= limit:
            await message.answer(f'Нужен текст от 1 до {limit} символов. Отмена: /cancel')
            return
        if operation == 'a_url':
            if text == '-':
                text = ''
            else:
                try:
                    url = urlparse(text)
                    valid = text.startswith('https://') and bool(url.netloc) and bool(url.hostname) and not any(c.isspace() or ord(c) < 32 for c in text)
                    url.port
                except ValueError:
                    valid = False
                if not valid:
                    await message.answer('Нужен HTTPS URL с адресом сайта или - для очистки. Отмена: /cancel')
                    return
        sid = data['section_id']
        if not await store.one('SELECT id FROM sections WHERE id=?', (sid,)):
            await state.clear()
            return
        column = {'a_title': 'title', 'a_body': 'body', 'a_url': 'url'}[operation]
        await store.execute(f'UPDATE sections SET {column}=? WHERE id=?', (text, sid))
        await state.clear()
        await admin_edit_panel(message, int(sid))

    @dp.message(Form.ticket)
    @dp.message(Form.story)
    @dp.message(Form.reply)
    async def submit(message: Message, state: FSMContext, bot: Bot):
        text = (message.text or '').strip()
        current = await state.get_state()
        minimum = 1 if current == Form.reply.state else 30
        if not minimum <= len(text) <= 2500:
            await message.answer(f'Нужен текст длиной от {minimum} до 2500 символов. Файлы не принимаются. Отмена: /cancel')
            return
        data = await state.get_data()
        uid = message.from_user.id
        if current == Form.reply.state:
            if uid not in admins:
                await state.clear()
                return
            row = await store.one("SELECT * FROM tickets WHERE id=? AND status='open'", (data['ticket_id'],))
            if not row:
                await state.clear()
                await message.answer('Обращение закрыто или удалено.')
                return
            rid = await store.execute('INSERT INTO replies(ticket_id, admin_id, body) VALUES (?,?,?)', (row['id'], uid, text))
            await state.clear()
            try:
                await bot.send_message(row['user_id'], f'<b>Ответ по обращению №{row["id"]}</b>\n\n{escape(text)}', reply_markup=BACK)
            except TelegramAPIError:
                await message.answer('Ответ сохранен, но Telegram не доставил сообщение. Пользователь увидит его в «Мои обращения».')
            else:
                await store.execute('UPDATE replies SET delivered=1 WHERE id=?', (rid,))
                await message.answer('Ответ доставлен. Обращение остается открытым.', reply_markup=keyboard([('⚙️ К панели', 'admin')]))
            return
        table = 'tickets' if current == Form.ticket.state else 'stories'
        recent = await store.one(f"SELECT COUNT(*) AS n FROM {table} WHERE user_id=? AND created_at >= datetime('now','-1 day')", (uid,))
        if recent['n'] >= 5:
            await state.clear()
            await message.answer('Лимит: 5 отправок этого типа за 24 часа. Попробуйте позже.', reply_markup=BACK)
            return
        if table == 'tickets':
            rid = await store.execute('INSERT INTO tickets(user_id, category, body) VALUES (?,?,?)', (uid, data['category'], text))
            response = f'Обращение №{rid} зарегистрировано. Ответ администратора придет сюда. Срок ответа зависит от загрузки.'
        else:
            rid = await store.execute('INSERT INTO stories(user_id, body) VALUES (?,?)', (uid, text))
            response = f'История №{rid} отправлена на модерацию. Спасибо за ваш опыт.'
        await state.clear()
        await message.answer(response, reply_markup=BACK)
        await notify(bot, f'Новое {"обращение" if table == "tickets" else "предложение истории"} №{rid}.',
                     keyboard([('📨 Открыть очередь', 'a_tickets:0' if table == 'tickets' else 'a_stories:0')]))

    @dp.message()
    async def fallback(message: Message):
        await section_view(message, message.from_user.id, await store.one("SELECT * FROM sections WHERE slug='home'"))

    return dp


async def cleanup_loop(store):
    """Prune old click-analytics rows so the events table (and privacy exposure) doesn't grow forever."""
    while True:
        try:
            removed = await store.prune_events(EVENTS_RETENTION_DAYS)
            if removed:
                logging.info('Pruned %s events older than %s days', removed, EVENTS_RETENTION_DAYS)
        except Exception:
            logging.exception('Event cleanup failed')
        await asyncio.sleep(24 * 60 * 60)


async def backup_loop():
    """Daily copy of the database (hosting like Amvera has no cron). Keeps the last BACKUP_KEEP copies."""
    await asyncio.sleep(3600)
    while True:
        try:
            await asyncio.to_thread(backup.main)
        except SystemExit as exc:
            logging.warning('Backup skipped: %s', exc)
        except Exception:
            logging.exception('Backup failed')
        await asyncio.sleep(24 * 60 * 60)


def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
        handlers=[
            logging.StreamHandler(),
            RotatingFileHandler(str((data_dir() or Path('.')) / 'bot.log'), maxBytes=2_000_000, backupCount=5, encoding='utf-8'),
        ],
    )
    # Keep aiogram/aiohttp internals at WARNING; only our own polling-retry logs at INFO.
    logging.getLogger('aiogram').setLevel(logging.WARNING)
    logging.getLogger('aiohttp').setLevel(logging.WARNING)


async def run_with_reconnect(dp, bot, commands=None):
    """Long polling with exponential backoff. Handles the case where api.telegram.org
    is temporarily unreachable (blocked network, DNS failure, ISP timeout) instead of
    crashing the whole process, which was the failure seen in the earlier logs.
    set_my_commands is retried here too (not just polling) — a network hiccup on that
    single call used to crash startup before polling ever got a chance to reconnect."""
    delay = 5
    max_delay = 300
    commands_set = commands is None
    while True:
        try:
            if not commands_set:
                await bot.set_my_commands(commands)
                commands_set = True
            await dp.start_polling(bot, handle_as_tasks=False)
            return  # graceful shutdown (e.g. Ctrl+C bubbled up as normal exit)
        except (TelegramNetworkError, ClientConnectorError, TimeoutError, OSError) as exc:
            logging.warning('Network error talking to Telegram (%s). Retrying in %ss.', exc, delay)
        except TelegramRetryAfter as exc:
            delay = max(delay, exc.retry_after)
            logging.warning('Telegram rate limit hit. Retrying in %ss.', delay)
        except asyncio.CancelledError:
            raise
        except Exception:
            logging.exception('Unexpected error in polling loop. Retrying in %ss.', delay)
        await asyncio.sleep(delay)
        delay = min(delay * 2, max_delay)


async def main():
    load_dotenv()
    token = os.getenv('BOT_TOKEN', '').strip()
    admins = {int(value.strip()) for value in os.getenv('ADMIN_IDS', '').split(',') if value.strip()}
    community = os.getenv('COMMUNITY_URL', '').strip()
    proxy = os.getenv('BOT_PROXY', '').strip() or None  # e.g. http://user:pass@host:port or socks5://host:port
    url = urlparse(community)
    if not token or not admins or (community and (url.scheme != 'https' or url.netloc != 't.me' or not url.path.strip('/'))):
        raise SystemExit('Configure BOT_TOKEN and ADMIN_IDS; optional COMMUNITY_URL must be https://t.me/...')
    seed_templates()
    default_db = str(data_dir() / 'bot.db') if data_dir() else 'bot.db'
    store = Storage(os.getenv('DATABASE_PATH') or default_db)
    await store.connect()
    session = AiohttpSession(proxy=proxy, timeout=30)
    bot = Bot(token, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    cleanup_task = asyncio.create_task(cleanup_loop(store))
    backup_task = asyncio.create_task(backup_loop())

    async def send_to_user(user_id, text):
        """Used by the web admin to deliver ticket replies through Telegram."""
        try:
            await bot.send_message(user_id, text, reply_markup=BACK)
            return True
        except TelegramAPIError:
            return False

    web_runner = await start_web(store, admins, send_to_user, os.environ)
    try:
        commands = [
            {'command': 'start', 'description': '🏠 Главное меню'},
            {'command': 'cancel', 'description': '❌ Отменить ввод'},
            {'command': 'delete_me', 'description': '🗑 Удалить мои данные'},
        ]
        dp = build_dispatcher(store, admins, community)
        await run_with_reconnect(dp, bot, commands)
    finally:
        if web_runner:
            await web_runner.cleanup()
        cleanup_task.cancel()
        backup_task.cancel()
        await store.db.close()
        await bot.session.close()


if __name__ == '__main__':
    load_dotenv()
    if data_dir():
        data_dir().mkdir(parents=True, exist_ok=True)
    setup_logging()
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
