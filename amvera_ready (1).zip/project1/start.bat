@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if exist ".venv\Scripts\python.exe" goto install
python --version >nul 2>&1
if errorlevel 1 (
    echo Install Python 3.11 or newer from https://www.python.org/downloads/
    echo Enable "Add Python to PATH" during installation.
    pause
    exit /b 1
)
python -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" configure.py
if errorlevel 1 goto failed
echo Starting bot. Keep this window open. Press Ctrl+C to stop.
echo Admin website: http://localhost:8080  (login: admin)
:run
".venv\Scripts\python.exe" bot.py
if errorlevel 1 (
    echo Bot exited unexpectedly. See bot.log for details. Restarting in 10s. Press Ctrl+C now to stop instead.
    timeout /t 10 >nul
    goto run
)
pause
exit /b 0
:failed
echo Startup failed. Read the error above. Do not share your token.
pause
exit /b 1
