"""Create a secret for two-factor login to the web admin.

    .venv\\Scripts\\python make_totp.py

Add the printed secret to your authenticator app (Google Authenticator, Aegis, 2FAS...)
with "enter a setup key" (type: time-based), and put the same value into the variable
WEB_TOTP_SECRET (in .env locally, or as a secret in the cloud panel).
"""

import base64
import secrets


def main():
    secret = base64.b32encode(secrets.token_bytes(20)).decode()
    print('\nСекретный ключ (вводится в приложение-аутентификатор вручную):\n')
    print(secret)
    print('\nТип ключа: по времени. Этот же ключ запишите в переменную WEB_TOTP_SECRET.')
    print('Не показывайте ключ никому: он эквивалентен второму фактору входа.')


if __name__ == '__main__':
    main()
