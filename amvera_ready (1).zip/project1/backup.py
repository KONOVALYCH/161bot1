"""Back up the bot's SQLite database safely, even while the bot is running.

Usage:
    .venv\\Scripts\\python backup.py

Uses SQLite's online backup API (via the stdlib sqlite3 module) instead of copying
the .db file directly, which would risk grabbing a half-written file if the bot is
writing at the same instant. Keeps the most recent N backups and deletes older ones.

Recommended: schedule this daily with Windows Task Scheduler
(Action: start a program -> .venv\\Scripts\\python.exe, Arguments: backup.py,
Start in: this project folder).
"""

import os
import sqlite3
from datetime import datetime
from pathlib import Path

from dotenv import dotenv_values

KEEP = int(os.getenv('BACKUP_KEEP', '14'))


def main():
    root = Path(__file__).resolve().parent
    config = dotenv_values(root / '.env')
    folder = os.environ.get('DATA_DIR', '').strip()
    default_db = (Path(folder) / 'bot.db') if folder else root / 'bot.db'
    db_path = root / (os.environ.get('DATABASE_PATH') or config.get('DATABASE_PATH') or str(default_db))
    if not db_path.exists():
        raise SystemExit(f'Database not found: {db_path}')

    backups_dir = db_path.parent / 'backups'
    backups_dir.mkdir(exist_ok=True)
    stamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    dest_path = backups_dir / f'bot_{stamp}.db'

    source = sqlite3.connect(str(db_path))
    dest = sqlite3.connect(str(dest_path))
    with dest:
        source.backup(dest)
    source.close()
    dest.close()
    print(f'Backup written: {dest_path}')

    existing = sorted(backups_dir.glob('bot_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in existing[KEEP:]:
        old.unlink()
        print(f'Removed old backup: {old.name}')


if __name__ == '__main__':
    main()
