import io
import re
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

import aiohttp
from aiohttp.test_utils import TestClient, TestServer

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from storage import Storage  # noqa: E402
from web_admin import WebAdmin, hash_password, valid_https_url, verify_password  # noqa: E402

PASSWORD = 'correct horse battery'


class WebAdminTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.store = Storage(':memory:')
        await self.store.connect()
        self.sent = []
        self.deliver = True
        self.tmp = tempfile.TemporaryDirectory()
        self.env = Path(self.tmp.name) / '.env'
        self.env.write_text('')

        async def send(uid, text):
            self.sent.append((uid, text))
            return self.deliver

        self.templates = Path(self.tmp.name) / 'templates'
        self.templates.mkdir()
        self.panel = WebAdmin(self.store, {42}, send, hash_password(PASSWORD), env_path=str(self.env), templates_dir=self.templates)
        self.server = TestServer(self.panel.app)
        await self.server.start_server()
        self.panel.allowed_hosts = lambda: {f'127.0.0.1:{self.server.port}'}
        self.client = TestClient(self.server)
        await self.client.start_server()

    async def asyncTearDown(self):
        await self.client.close()
        await self.store.db.close()
        self.tmp.cleanup()

    async def login(self):
        r = await self.client.post('/login', data={'user': 'admin', 'password': PASSWORD}, allow_redirects=False)
        self.assertEqual(r.status, 303)
        page = await (await self.client.get('/')).text()
        return re.search(r'name="csrf" value="([^"]+)"', page).group(1)

    async def post(self, path, csrf, **data):
        return await self.client.post(path, data={'csrf': csrf, **data}, allow_redirects=False)

    async def test_requires_login(self):
        for path in ('/', '/tickets', '/menu', '/services', '/stories', '/settings'):
            r = await self.client.get(path, allow_redirects=False)
            self.assertEqual((r.status, r.headers['Location']), (303, '/login'), path)
        r = await self.client.post('/menu/1/delete', data={}, allow_redirects=False)
        self.assertEqual(r.status, 303)

    async def test_wrong_password_and_lockout(self):
        for _ in range(5):
            r = await self.client.post('/login', data={'user': 'admin', 'password': 'nope'})
            self.assertIn('Неверный', await r.text())
        r = await self.client.post('/login', data={'user': 'admin', 'password': PASSWORD})
        self.assertIn('Слишком много', await r.text())

    async def test_bad_host_rejected(self):
        r = await self.client.get('/login', headers={'Host': 'evil.example'})
        self.assertEqual(r.status, 400)

    async def test_cross_origin_post_rejected(self):
        csrf = await self.login()
        r = await self.client.post('/logout', data={'csrf': csrf}, headers={'Origin': 'https://evil.example'}, allow_redirects=False)
        self.assertEqual(r.status, 403)

    async def test_csrf_required(self):
        await self.login()
        r = await self.client.post('/menu/1/delete', data={}, allow_redirects=False)
        self.assertEqual(r.status, 403)
        r = await self.client.post('/menu/1/delete', data={'csrf': 'x'}, allow_redirects=False)
        self.assertEqual(r.status, 403)

    async def test_security_headers_and_cookie(self):
        r = await self.client.post('/login', data={'user': 'admin', 'password': PASSWORD}, allow_redirects=False)
        cookie = r.headers['Set-Cookie']
        self.assertIn('HttpOnly', cookie)
        self.assertIn('SameSite=Strict', cookie)
        r = await self.client.get('/')
        self.assertIn("default-src 'none'", r.headers['Content-Security-Policy'])
        self.assertEqual(r.headers['X-Frame-Options'], 'DENY')

    async def test_dashboard_renders(self):
        await self.login()
        r = await self.client.get('/')
        self.assertEqual(r.status, 200)
        self.assertIn('пользователей', await r.text())

    async def test_ticket_reply_delivered(self):
        csrf = await self.login()
        await self.store.touch(7)
        tid = await self.store.execute("INSERT INTO tickets(user_id,category,body) VALUES (7,'bank','<script>alert(1)</script> текст')")
        page = await (await self.client.get(f'/tickets/{tid}')).text()
        self.assertNotIn('<script>alert', page)
        self.assertIn('&lt;script&gt;', page)
        r = await self.post(f'/tickets/{tid}/reply', csrf, body='Ответ <b>админа</b>')
        self.assertEqual(r.status, 303)
        self.assertEqual(self.sent[0][0], 7)
        self.assertIn('&lt;b&gt;', self.sent[0][1])
        row = await self.store.one('SELECT * FROM replies WHERE ticket_id=?', (tid,))
        self.assertEqual((row['delivered'], row['admin_id']), (1, 42))

    async def test_ticket_reply_undelivered_and_validation(self):
        csrf = await self.login()
        await self.store.touch(7)
        tid = await self.store.execute("INSERT INTO tickets(user_id,category,body) VALUES (7,'bank','x')")
        self.deliver = False
        await self.post(f'/tickets/{tid}/reply', csrf, body='hello')
        self.assertEqual((await self.store.one('SELECT delivered FROM replies'))['delivered'], 0)
        await self.post(f'/tickets/{tid}/reply', csrf, body='y' * 2501)
        self.assertEqual((await self.store.one('SELECT COUNT(*) n FROM replies'))['n'], 1)
        await self.post(f'/tickets/{tid}/close', csrf)
        self.assertEqual((await self.store.one('SELECT status FROM tickets'))['status'], 'closed')
        await self.post(f'/tickets/{tid}/reply', csrf, body='after close')
        self.assertEqual((await self.store.one('SELECT COUNT(*) n FROM replies'))['n'], 1)

    async def test_stories_moderation(self):
        csrf = await self.login()
        await self.store.touch(7)
        sid = await self.store.execute("INSERT INTO stories(user_id,body) VALUES (7,'story')")
        await self.post(f'/stories/{sid}/publish', csrf, back='pending')
        self.assertEqual((await self.store.one('SELECT status FROM stories'))['status'], 'published')
        await self.post(f'/stories/{sid}/reject', csrf, back='published')
        self.assertEqual((await self.store.one('SELECT status FROM stories'))['status'], 'rejected')

    async def test_menu_edit_rules(self):
        csrf = await self.login()
        home = await self.store.one("SELECT id FROM sections WHERE slug='home'")
        comm = await self.store.one("SELECT id FROM sections WHERE slug='community'")
        r = await self.post(f'/menu/{comm["id"]}/save', csrf, title='Чат', body='текст', url='http://t.me/x')
        self.assertIn('m=', r.headers['Location'])
        self.assertEqual((await self.store.one("SELECT url FROM sections WHERE slug='community'"))['url'], '')
        await self.post(f'/menu/{comm["id"]}/save', csrf, title='Чат', body='текст', url='https://t.me/mychat')
        self.assertEqual((await self.store.one("SELECT url FROM sections WHERE slug='community'"))['url'], 'https://t.me/mychat')
        await self.post(f'/menu/{home["id"]}/delete', csrf)
        self.assertIsNotNone(await self.store.one("SELECT id FROM sections WHERE slug='home'"))
        await self.post(f'/menu/{comm["id"]}/save', csrf, title='', body='x', url='')
        self.assertEqual((await self.store.one("SELECT title FROM sections WHERE slug='community'"))['title'], 'Чат')
        await self.post('/menu/new', csrf, parent=str(home['id']), title='Новый', body='Текст', url='')
        new = await self.store.one("SELECT * FROM sections WHERE title='Новый'")
        self.assertEqual(new['parent_id'], home['id'])
        parent = await self.store.one("SELECT id FROM sections WHERE slug='faq'")
        await self.post(f'/menu/{parent["id"]}/delete', csrf)  # has children
        self.assertIsNotNone(await self.store.one("SELECT id FROM sections WHERE slug='faq'"))
        await self.post(f'/menu/{new["id"]}/delete', csrf)
        self.assertIsNone(await self.store.one("SELECT id FROM sections WHERE title='Новый'"))

    async def test_menu_move(self):
        csrf = await self.login()
        home = await self.store.one("SELECT id FROM sections WHERE slug='home'")
        kids = await self.store.rows('SELECT id FROM sections WHERE parent_id=? ORDER BY position, id', (home['id'],))
        await self.post(f'/menu/{kids[1]["id"]}/move/up', csrf)
        after = await self.store.rows('SELECT id FROM sections WHERE parent_id=? ORDER BY position, id', (home['id'],))
        self.assertEqual([after[0]['id'], after[1]['id']], [kids[1]['id'], kids[0]['id']])

    async def test_services_crud(self):
        csrf = await self.login()
        await self.post('/services/new', csrf, title='Услуга', description='d', price='5 000 ₽')
        s = await self.store.one('SELECT * FROM paid_services')
        self.assertEqual((s['price'], s['active']), (5000, 1))
        await self.post('/services/new', csrf, title='Плохая', description='', price='-1')
        await self.post('/services/new', csrf, title='Плохая2', description='', price='abc')
        self.assertEqual((await self.store.one('SELECT COUNT(*) n FROM paid_services'))['n'], 1)
        await self.post(f'/services/{s["id"]}/toggle', csrf)
        self.assertEqual((await self.store.one('SELECT active FROM paid_services'))['active'], 0)
        await self.post(f'/services/{s["id"]}/save', csrf, title='Новая', description='', price='10')
        self.assertEqual((await self.store.one('SELECT title, price FROM paid_services'))['price'], 10)
        await self.post(f'/services/{s["id"]}/delete', csrf)
        self.assertIsNone(await self.store.one('SELECT id FROM paid_services'))

    async def test_change_password_persists(self):
        csrf = await self.login()
        await self.post('/settings/password', csrf, old='wrong', new='another long password')
        self.assertTrue(verify_password(PASSWORD, self.panel.password_hash))
        await self.post('/settings/password', csrf, old=PASSWORD, new='another long password')
        self.assertTrue(verify_password('another long password', self.panel.password_hash))
        from dotenv import dotenv_values
        self.assertTrue(verify_password('another long password', dotenv_values(self.env)['WEB_PASSWORD_HASH']))

    @staticmethod
    def fake_docx(text='v1'):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('[Content_Types].xml', '<x/>')
            z.writestr('word/document.xml', f'<w>{text}</w>')
        return buf.getvalue()

    async def upload(self, csrf, name, data, filename='x.docx'):
        form = aiohttp.FormData()
        form.add_field('csrf', csrf)
        form.add_field('file', data, filename=filename, content_type='application/octet-stream')
        return await self.client.post(f'/documents/{name}/upload', data=form, allow_redirects=False)

    async def test_documents_upload_backup_restore(self):
        csrf = await self.login()
        target = self.templates / 'bank_return.docx'
        target.write_bytes(self.fake_docx('old'))
        self.assertEqual((await self.client.get('/documents')).status, 200)
        r = await self.upload(csrf, 'bank_return.docx', self.fake_docx('new'))
        self.assertEqual(r.status, 303)
        self.assertIn(b'new', zipfile.ZipFile(target).read('word/document.xml'))
        self.assertEqual(len(list((self.templates / 'backups').glob('bank_return.*.docx'))), 1)
        dl = await self.client.get('/documents/bank_return.docx/download')
        self.assertEqual(dl.status, 200)
        self.assertIn('attachment', dl.headers['Content-Disposition'])
        await self.post('/documents/bank_return.docx/restore', csrf)
        self.assertIn(b'old', zipfile.ZipFile(target).read('word/document.xml'))

    async def test_documents_rejects_bad_files(self):
        csrf = await self.login()
        target = self.templates / 'mvd_request.docx'
        target.write_bytes(self.fake_docx('keep'))
        for bad in (b'not a zip', b'PK\x03\x04broken', self.fake_docx()[:-30]):
            await self.upload(csrf, 'mvd_request.docx', bad)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('hello.txt', 'x')
        await self.upload(csrf, 'mvd_request.docx', buf.getvalue())
        await self.upload(csrf, 'mvd_request.docx', b'PK' + b'0' * (5 * 1024 * 1024))
        self.assertIn(b'keep', zipfile.ZipFile(target).read('word/document.xml'))
        r = await self.upload(csrf, '..%2Fevil.docx', self.fake_docx())
        self.assertEqual(r.status, 404)
        self.assertFalse((Path(self.tmp.name) / 'evil.docx').exists())
        r = await self.client.get('/documents/passwd/download')
        self.assertEqual(r.status, 404)

    async def test_documents_requires_csrf(self):
        await self.login()
        form = aiohttp.FormData()
        form.add_field('file', self.fake_docx(), filename='x.docx')
        r = await self.client.post('/documents/bank_return.docx/upload', data=form, allow_redirects=False)
        self.assertEqual(r.status, 403)

    def test_helpers(self):
        self.assertTrue(valid_https_url('https://t.me/chat'))
        for bad in ('http://x.ru', 'https://', 'javascript:alert(1)', 'https://a b.ru', 'https://x.ru:99999'):
            self.assertFalse(valid_https_url(bad), bad)
        h = hash_password('abc')
        self.assertTrue(verify_password('abc', h))
        self.assertFalse(verify_password('abd', h))
        self.assertFalse(verify_password('abc', 'garbage'))


if __name__ == '__main__':
    unittest.main()
