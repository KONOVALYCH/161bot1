import asyncio
import os
import re
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from aiohttp.test_utils import TestClient, TestServer

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import documents  # noqa: E402
from storage import Storage  # noqa: E402
from web_admin import WebAdmin, hash_password, start_web, totp_code, verify_password, verify_totp  # noqa: E402

PASSWORD = 'correct horse battery'
SECRET = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ'  # RFC 6238 test key "12345678901234567890"


class TotpTests(unittest.TestCase):
    def test_rfc6238_vector(self):
        self.assertEqual(totp_code(SECRET, at=59, digits=8), '94287082')
        self.assertEqual(totp_code(SECRET, at=1111111109, digits=8), '07081804')

    def test_verify_window(self):
        now = time.time()
        self.assertTrue(verify_totp(SECRET, totp_code(SECRET, now)))
        self.assertTrue(verify_totp(SECRET, totp_code(SECRET, now - 30)))
        self.assertFalse(verify_totp(SECRET, totp_code(SECRET, now - 300)))
        self.assertFalse(verify_totp(SECRET, ''))


class CloudModeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.store = Storage(':memory:')
        await self.store.connect()
        self.tmp = tempfile.TemporaryDirectory()
        self.hash_file = Path(self.tmp.name) / 'web_password.hash'
        self.panel = WebAdmin(self.store, {42}, None, hash_password(PASSWORD), port=80,
                              extra_hosts=['bot.example.amvera.tech'], secure_cookies=True,
                              trust_proxy=True, totp_secret=SECRET, hash_file=self.hash_file,
                              templates_dir=Path(self.tmp.name) / 't')
        self.server = TestServer(self.panel.app)
        await self.server.start_server()
        self.client = TestClient(self.server)
        await self.client.start_server()
        self.h = {'Host': 'bot.example.amvera.tech', 'Origin': 'https://bot.example.amvera.tech'}

    async def asyncTearDown(self):
        await self.client.close()
        await self.store.db.close()
        self.tmp.cleanup()

    async def login(self, code=None, ip='1.2.3.4', password=PASSWORD):
        data = {'user': 'admin', 'password': password, 'code': code or totp_code(SECRET)}
        return await self.client.post('/login', data=data, headers={**self.h, 'X-Forwarded-For': f'9.9.9.9, {ip}'}, allow_redirects=False)

    async def test_domain_allowed_and_other_host_rejected(self):
        self.assertEqual((await self.client.get('/login', headers=self.h)).status, 200)
        self.assertEqual((await self.client.get('/login', headers={'Host': 'evil.example'})).status, 400)
        self.assertIn('Код из приложения', await (await self.client.get('/login', headers=self.h)).text())

    async def test_login_needs_code_and_cookie_is_secure(self):
        r = await self.login(code='000000')
        self.assertEqual(r.status, 200)
        r = await self.login()
        self.assertEqual(r.status, 303)
        self.assertIn('Secure', r.headers['Set-Cookie'])
        page = await self.client.get('/', headers={**self.h, 'Cookie': self.cookie(r)})
        self.assertEqual(page.status, 200)
        self.assertIn('Обзор', await page.text())
        self.assertIn('Strict-Transport-Security', page.headers)

    async def test_lockout_is_per_client(self):
        for _ in range(5):
            await self.login(password='bad', ip='6.6.6.6')
        locked = await self.login(ip='6.6.6.6')
        self.assertIn('Слишком много', await locked.text())
        ok = await self.login(ip='7.7.7.7')  # another client is not affected
        self.assertEqual(ok.status, 303)

    @staticmethod
    def cookie(response):
        return response.headers['Set-Cookie'].split(';')[0]

    async def test_password_change_goes_to_data_file(self):
        r = await self.login()
        self.h = {**self.h, 'Cookie': self.cookie(r)}  # the client does not re-send a Secure cookie over http
        page = await (await self.client.get('/settings', headers=self.h)).text()
        csrf = re.search(r'name="csrf" value="([^"]+)"', page).group(1)
        await self.client.post('/settings/password', data={'csrf': csrf, 'old': PASSWORD, 'new': 'a brand new password'},
                               headers=self.h, allow_redirects=False)
        self.assertTrue(verify_password('a brand new password', self.hash_file.read_text()))


class AmveraAutoModeTests(unittest.IsolatedAsyncioTestCase):
    async def start(self, env):
        from web_admin import start_web
        store = Storage(':memory:')
        await store.connect()
        runner = await start_web(store, {1}, None, env)
        return store, runner

    async def test_refuses_public_start_without_2fa(self):
        store, runner = await self.start({'AMVERA': '1', 'PORT': '0', 'WEB_PASSWORD_HASH': hash_password(PASSWORD)})
        self.assertIsNone(runner)
        await store.db.close()

    async def test_amvera_defaults_with_2fa(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {'DATA_DIR': tmp}):
            store, runner = await self.start({'AMVERA': '1', 'PORT': '0', 'WEB_PASSWORD_HASH': hash_password(PASSWORD), 'WEB_TOTP_SECRET': SECRET})
            self.assertIsNotNone(runner)
            await runner.cleanup()
            await store.db.close()

    def test_amvera_marker_selects_data_folder(self):
        with mock.patch.dict(os.environ, {'AMVERA': '1'}, clear=False):
            os.environ.pop('DATA_DIR', None)
            self.assertEqual(str(documents.data_dir()), '/data')

    async def test_any_host_origin_must_match_host(self):
        store = Storage(':memory:')
        await store.connect()
        panel = WebAdmin(store, {1}, None, hash_password(PASSWORD), extra_hosts=['*'], secure_cookies=True, totp_secret=SECRET)
        server = TestServer(panel.app)
        await server.start_server()
        client = TestClient(server)
        await client.start_server()
        ok = await client.get('/login', headers={'Host': 'any.example.tech'})
        self.assertEqual(ok.status, 200)
        bad = await client.post('/login', data={}, headers={'Host': 'any.example.tech', 'Origin': 'https://evil.example'})
        self.assertEqual(bad.status, 403)
        await client.close()
        await store.db.close()


class DataDirTests(unittest.IsolatedAsyncioTestCase):
    def test_templates_seeded_once_and_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {'DATA_DIR': tmp}):
            documents.seed_templates()
            target = Path(tmp) / 'templates'
            names = {p.name for p in target.glob('*.docx')}
            self.assertEqual(names, set(documents.BANK_FILES.values()) | set(documents.CBR_FILES.values()) | {documents.MVD_FILE})
            (target / 'mvd_request.docx').write_bytes(b'edited in web admin')
            documents.seed_templates()
            self.assertEqual((target / 'mvd_request.docx').read_bytes(), b'edited in web admin')
            _, path = documents.mvd_document()
            self.assertEqual(path, target / 'mvd_request.docx')

    def test_without_data_dir_uses_project_folder(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop('DATA_DIR', None)
            self.assertEqual(documents.get_templates_dir(), documents.DEFAULT_TEMPLATES_DIR)
            documents.seed_templates()  # no-op

    async def test_start_web_reads_hash_file_and_binds(self):
        store = Storage(':memory:')
        await store.connect()
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / 'web_password.hash').write_text(hash_password('from file password'))
            env = {'DATA_DIR': tmp, 'WEB_PASSWORD_HASH': hash_password('from variable'), 'WEB_PORT': '0'}
            with mock.patch.dict(os.environ, {'DATA_DIR': tmp}):
                runner = await start_web(store, {1}, None, env)
            self.assertIsNotNone(runner)
            await runner.cleanup()
        self.assertIsNone(await start_web(store, {1}, None, {'WEB_PASSWORD_HASH': ''}))
        self.assertIsNone(await start_web(store, {1}, None, {'WEB_ENABLED': '0', 'WEB_PASSWORD_HASH': 'x'}))
        await store.db.close()


if __name__ == '__main__':
    unittest.main()
