import aiosqlite


class Storage:
    def __init__(self, path):
        self.path = path

    async def connect(self):
        self.db = await aiosqlite.connect(self.path)
        self.db.row_factory = aiosqlite.Row
        await self.db.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA foreign_keys=ON;
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                category TEXT NOT NULL,
                body TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'open',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS replies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL REFERENCES tickets(id),
                admin_id INTEGER NOT NULL,
                body TEXT NOT NULL,
                delivered INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS stories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id),
                body TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                moderator_id INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS tickets_status ON tickets(status, id);
            CREATE INDEX IF NOT EXISTS stories_status ON stories(status, id);
            CREATE INDEX IF NOT EXISTS events_date ON events(created_at);
            CREATE TABLE IF NOT EXISTS sections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                slug TEXT UNIQUE,
                parent_id INTEGER REFERENCES sections(id),
                title TEXT NOT NULL,
                body TEXT NOT NULL DEFAULT '',
                position INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS paid_services (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                price INTEGER NOT NULL DEFAULT 0,
                position INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS paid_services_order ON paid_services(active, position, id);
        """)
        columns = await self.rows('PRAGMA table_info(sections)')
        if 'url' not in {column['name'] for column in columns}:
            await self.db.execute("ALTER TABLE sections ADD COLUMN url TEXT NOT NULL DEFAULT ''")
        FAQ_115 = [
            ('В чём разница между 115-ФЗ и 161-ФЗ?',
             '115-ФЗ — закон о противодействии отмыванию доходов: банк может отказать в операции или '
             'расторгнуть договор, если сочтёт клиента подозрительным («чёрный список»). 161-ФЗ — закон '
             'о национальной платёжной системе: банк временно приостанавливает конкретный перевод (обычно '
             'до 2 рабочих дней) при признаках мошенничества, не расторгая договор.'),
            ('Что такое «чёрный список» Банка России по 115-ФЗ?',
             'Перечень юридических и физических лиц, по которым банки направили сведения об отказе в '
             'проведении операции или расторжении договора. Формируется Банком России на основе данных '
             'Росфинмониторинга и рассылается банкам (Положение № 764-П).'),
            ('Как оспорить отказ банка по 115-ФЗ?',
             'Сначала письменно обратиться в сам банк с подтверждающими документами — ответ должен '
             'прийти в течение 10 рабочих дней. Если банк отказал повторно, в течение 6 месяцев с '
             'момента отказа можно обратиться в Межведомственную комиссию при Банке России (МВК).'),
            ('Как работает Межведомственная комиссия (МВК) при ЦБ?',
             'Рассматривает жалобы на отказы банков по 115-ФЗ в течение 20 рабочих дней (Положение № '
             '842-П от 23.09.2024). Решение обязательно для банка — он должен исполнить его в течение '
             '1 рабочего дня после получения.'),
            ('Может ли банк расторгнуть договор без подробных объяснений по 115-ФЗ?',
             'Закон о банковской тайне и противодействии финансированию терроризма позволяет банку не '
             'раскрывать детали, но он обязан письменно сообщить о самом факте отказа или расторжения '
             'договора.'),
            ('Как проверить, входит ли компания или ИП в группу высокого риска ЦБ?',
             'На сайте Банка России есть сервис проверки контрагента по ИНН на принадлежность к группе '
             'высокого уровня риска в рамках платформы «Знай своего клиента».'),
            ('Что делать, если банк заблокировал операции из-за контрагента из чёрного списка?',
             'Подготовить документы, подтверждающие реальность и экономический смысл сделки — договор, '
             'накладные, переписку — и направить их в банк как обоснование операции.'),
        ]
        FAQ_161 = [
            ('Что такое 161-ФЗ и чем он отличается от полной блокировки счёта?',
             'Это закон «О национальной платёжной системе». По нему банк не блокирует весь счёт, а '
             'приостанавливает конкретную подозрительную операцию максимум на 2 рабочих дня; снять '
             'наличные в отделении по паспорту обычно можно даже во время ограничения.'),
            ('По каким признакам банк приостанавливает операцию по 161-ФЗ?',
             'По перечню, который определяет Банк России (Приказ № ОД-2506): например, совпадение '
             'реквизитов получателя с базой мошеннических операций ЦБ, использование ранее '
             'скомпрометированного устройства, нетипичный паттерн переводов. С января 2026 года действует '
             '12 признаков вместо прежних 6.'),
            ('Что произойдёт, если банк не разблокирует операцию за 2 дня?',
             'В зависимости от ситуации деньги могут вернуться отправителю, либо счёт получателя '
             'попадает в базу данных ЦБ по операциям без согласия клиента — из-за этого теряется доступ '
             'к дистанционному обслуживанию до исключения из базы.'),
            ('Как исключить свои данные из базы Банка России?',
             'Подать заявление через интернет-приёмную ЦБ (cbr.ru/reception) либо через свой банк, '
             'приложив документы, подтверждающие легальность операции.'),
            ('Может ли банк потребовать документы для разблокировки?',
             'Да, банк вправе запросить подтверждения: договор, назначение платежа, переписку с '
             'контрагентом, документы о происхождении средств.'),
            ('Что делать, если банк «рассматривает» обращение уже несколько недель?',
             'Направить письменную претензию с требованием ответа в разумный срок, а затем — жалобу в '
             'Банк России на бездействие банка через интернет-приёмную.'),
            ('Что изменилось в проверках с 1 марта 2026 года?',
             'Банки при переводах дополнительно проверяют получателя по государственной информационной '
             'системе противодействия киберпреступлениям, что расширяет число оснований для временной '
             'приостановки операции.'),
        ]
        FAQ_MVD = [
            ('Означает ли блокировка по 161-ФЗ, что на меня завели уголовное дело?',
             'Нет. Попадание в базу ЦБ или временная приостановка операции — это банковская мера, а не '
             'решение следствия. Уголовное дело возбуждается отдельно, следственным органом, по своим '
             'основаниям.'),
            ('Как официально узнать, есть ли против меня уголовное дело?',
             'Направить письменный запрос в территориальный отдел МВД или Следственный комитет по месту '
             'жительства с просьбой сообщить о наличии либо отсутствии возбуждённого дела. Ответ обязаны '
             'дать в течение 30 дней (Федеральный закон № 59-ФЗ «О порядке рассмотрения обращений '
             'граждан»).'),
            ('Есть ли другие способы проверить сведения о деле?',
             'Можно поискать себя в картотеке «Производство по материалам» на сайте районного суда по '
             'месту жительства, либо поручить проверку адвокату — у него больше возможностей направлять '
             'официальные запросы.'),
            ('Кто обязан уведомить меня, если дело всё же возбуждено?',
             'По статье 146 УПК РФ лицо, в отношении которого возбуждено дело, должно получить копию '
             'постановления. Но если дело возбуждено «по факту» в отношении неустановленного лица, '
             'уведомление могут не присылать.'),
            ('Что делать, если пришла повестка или вызов на допрос из-за операций по карте?',
             'Уточнить у следователя свой статус (свидетель или подозреваемый), при необходимости — '
             'обратиться к адвокату до допроса, сохранить все банковские документы по спорной операции.'),
            ('Обязательно ли обращаться в МВД, если банк просто заблокировал операцию?',
             'Нет. Для снятия обычной приостановки по 161-ФЗ обращение в МВД не требуется — это отдельный '
             'самостоятельный шаг, если есть основания опасаться уголовного преследования (например, вас '
             'вызывали, допрашивали, или деньги прошли через ваш счёт без вашего участия).'),
        ]

        def faq_seeds(prefix, parent, items):
            return [(f'{prefix}_{i}', parent, q, a) for i, (q, a) in enumerate(items, start=1)]

        seeds = [
            ('home', None, '🏠 161-ФЗ · Поддержка и опыт', 'Сообщество людей, столкнувшихся с ограничениями переводов. Здесь можно задать вопрос и изучить опыт других участников.\n\nНе являемся банком или Банком России. Разблокировку не гарантируем.'),
            ('community', 'home', '💬 Чат участников', 'Обменивайтесь опытом без персональных данных. Не переводите деньги за «гарантированную разблокировку» и не сообщайте коды из SMS.'),
            ('faq', 'home', '❓ Частые вопросы', 'Ответы на частые вопросы по 115-ФЗ, 161-ФЗ и обращениям в МВД. Общая информация, не юридическая консультация по вашему делу.'),
            ('faq_115', 'faq', '115-ФЗ', 'Отказы в операциях, чёрный список Банка России, Межведомственная комиссия.'),
            ('faq_161', 'faq', '161-ФЗ', 'Приостановка операций, база данных ЦБ, сроки разблокировки.'),
            ('faq_mvd', 'faq', '161-ФЗ и МВД', 'Как понять, что блокировка не связана с уголовным делом, и как это проверить официально.'),
            ('tickets', 'home', '📨 Обращения', 'Выберите банк, Банк России или МВД, чтобы скачать готовый шаблон документа (файл .docx). Заполните его своими данными перед отправкой.'),
            ('paid_services', 'home', '💳 Платные услуги', 'Индивидуальная подготовка документов и юридических обращений. Стоимость указана у каждой услуги.'),
            ('banks', 'tickets', '🏦 Банки (Сбер, ВТБ...)', 'Здесь собраны общие шаблоны обращений для банков. Выберите нужное заявление — отдельный выбор банка не требуется.'),
            ('stories', 'home', '📖 Истории разблокировки', 'Истории участников после модерации. Личный опыт не гарантирует результат.'),
            ('about', 'home', 'ℹ️ О проекте и безопасности', '161-ФЗ регулирует национальную платежную систему. Сначала уточните у банка норму закона и причину ограничения. Не путайте 161-ФЗ с 115-ФЗ. Бот не заменяет юридическую консультацию.'),
            ('cbr', 'tickets', '🏛 ЦБ (Исключение данных)', 'Выберите тип обращения в Банк России.'),
            ('mvd', 'tickets', '👮 МВД', 'Этот файл поможет узнать, заведено ли на ваше имя уголовное дело в связи с ограничениями по вашим банковским операциям. Заполните и направьте обращение в территориальный орган МВД по месту жительства.'),
            *faq_seeds('faq_115', 'faq_115', FAQ_115),
            *faq_seeds('faq_161', 'faq_161', FAQ_161),
            *faq_seeds('faq_mvd', 'faq_mvd', FAQ_MVD),
        ]
        for position, (slug, parent, title, body) in enumerate(seeds):
            await self.db.execute('INSERT OR IGNORE INTO sections(slug,parent_id,title,body,position) VALUES (?,(SELECT id FROM sections WHERE slug=?),?,?,?)',
                                  (slug, parent, title, body, position))
        # Migration: delete the old per-bank sections (Сбер/ВТБ/Альфа/Т-Банк/Газпром). Since the
        # "Банки" hub became a single generic document picker, these 5 rows are no longer linked
        # from anywhere in the menu — they were dead/orphaned entries cluttering "Управление меню".
        # Only delete if childless, so we never lose a subsection an admin may have added under one.
        await self.db.execute("""
            DELETE FROM sections
            WHERE slug IN ('sber','vtb','alfa','tbank','gazprom')
              AND id NOT IN (SELECT DISTINCT parent_id FROM sections WHERE parent_id IS NOT NULL)
        """)
        legacy_titles = {
            'home': ['161-ФЗ · Поддержка и опыт'], 'community': ['Чат участников'], 'tickets': ['Обращения'], 'paid_services': ['Платные услуги'],
            'stories': ['Истории разблокировки'], 'about': ['О проекте и безопасности'], 'banks': ['🏦 Банки', 'Банки'],
            'cbr': ['Банк России: исключение из базы', '🏛 Банк России: исключение из базы'],
        }
        new_titles = {slug: title for slug, _, title, _ in seeds}
        for slug, old_titles in legacy_titles.items():
            for old_title in old_titles:
                await self.db.execute('UPDATE sections SET title=? WHERE slug=? AND title=?', (new_titles[slug], slug, old_title))
        old_cbr_template = (
            'Кому: Банк России\nОт: [ваше ФИО, контактный телефон]\n\n'
            'Прошу рассмотреть вопрос об исключении сведений обо мне из базы данных Банка России, формируемой '
            'в соответствии со статьёй 9.1 Федерального закона № 161-ФЗ «О национальной платежной системе».\n\n'
            'Ранее ограничение было применено банком [название банка] __.__.____ по договору/счёту № ____. '
            'Приложение: ответ банка о причинах ограничения (при наличии).\n\n'
            'Дата: __.__.____\nПодпись: _____________'
        )
        legacy_bodies = {
            'tickets': [
                'Выберите банк или действие. Пять крупных банков РФ, не рейтинг. Обращения здесь направляются администраторам бота, а не в банк.',
                'Выберите банк или Банк России, чтобы посмотреть образец обращения, либо закажите индивидуальное обращение по вашей ситуации.',
            ],
            'banks': ['Выберите нужный документ. Шаблоны подходят для банков, в тексте документа оставлено поле для указания конкретного банка.'],
            'cbr': [old_cbr_template, 'Обращение об исключении сведений из базы данных Банка России. Решение принимает Банк России; бот не гарантирует исключение. Официальная интернет-приемная: https://www.cbr.ru/reception/'],
        }
        new_bodies = {slug: body for slug, _, _, body in seeds}
        for slug, old_bodies in legacy_bodies.items():
            for old_body in old_bodies:
                await self.db.execute('UPDATE sections SET body=? WHERE slug=? AND body=?', (new_bodies[slug], slug, old_body))
        await self.db.commit()

    async def execute(self, sql, params=()):
        cursor = await self.db.execute(sql, params)
        await self.db.commit()
        return cursor.lastrowid

    async def rows(self, sql, params=()):
        async with self.db.execute(sql, params) as cursor:
            return await cursor.fetchall()

    async def one(self, sql, params=()):
        rows = await self.rows(sql, params)
        return rows[0] if rows else None

    async def touch(self, user_id):
        await self.execute(
            "INSERT INTO users(id) VALUES (?) ON CONFLICT(id) DO UPDATE SET seen_at=CURRENT_TIMESTAMP",
            (user_id,),
        )

    async def event(self, name):
        await self.execute("INSERT INTO events(name) VALUES (?)", (name,))

    async def stats(self):
        return await self.one("""
            SELECT
              (SELECT COUNT(*) FROM users) AS users,
              (SELECT COUNT(*) FROM users WHERE joined_at >= datetime('now','-7 days')) AS new_users,
              (SELECT COUNT(*) FROM users WHERE seen_at >= datetime('now','-1 day')) AS active,
              (SELECT COUNT(*) FROM tickets) AS tickets,
              (SELECT COUNT(*) FROM tickets WHERE status='open') AS open_tickets,
              (SELECT COUNT(*) FROM tickets WHERE status='closed') AS closed_tickets,
              (SELECT COUNT(*) FROM stories WHERE status='pending') AS pending,
              (SELECT COUNT(*) FROM stories WHERE status='published') AS published,
              (SELECT COUNT(*) FROM replies WHERE delivered=1) AS replies
        """)

    async def click_stats(self):
        return await self.rows("SELECT name, COUNT(*) AS n FROM events WHERE name LIKE 'click:%' AND created_at >= datetime('now','-7 days') GROUP BY name ORDER BY n DESC, name")

    async def prune_events(self, days):
        cursor = await self.db.execute("DELETE FROM events WHERE created_at < datetime('now', ?)", (f'-{int(days)} days',))
        await self.db.commit()
        return cursor.rowcount
