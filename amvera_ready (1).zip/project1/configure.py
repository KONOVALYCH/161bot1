"""Interactive local setup. Secrets are never included in the release archive."""

from pathlib import Path

from aiogram.utils.token import TokenValidationError, validate_token
from getpass import getpass

from dotenv import dotenv_values, set_key

from web_admin import hash_password


def main():
    path = Path(__file__).resolve().parent / '.env'
    config = dotenv_values(path)
    token = (config.get('BOT_TOKEN') or config.get('TOKEN') or '').strip()
    while True:
        if not token:
            print('Вставьте токен от BotFather. Он будет виден в этом окне: не отправляйте скриншот.')
            try:
                token = input('BOT_TOKEN: ').strip()
            except (EOFError, KeyboardInterrupt):
                raise SystemExit('Настройка отменена.') from None
        if token.startswith('BOT_TOKEN='):
            token = token[len('BOT_TOKEN='):].strip()
        token = token.strip('\"\'').strip()
        try:
            validate_token(token)
            break
        except TokenValidationError:
            if not token:
                reason = 'получена пустая строка'
            elif any(ord(char) < 32 for char in token):
                reason = 'получен управляющий символ вместо текста; попробуйте вставить правой кнопкой мыши'
            elif any(char.isspace() for char in token):
                reason = 'внутри строки есть пробелы'
            elif ':' not in token:
                reason = 'нет двоеточия между ID бота и секретной частью'
            elif not token.partition(':')[0].isdigit():
                reason = 'перед двоеточием должны быть только цифры ID бота'
            else:
                reason = 'после двоеточия отсутствует секретная часть'
            print(f'Не удалось прочитать токен: {reason}. Повторите ввод.')
            token = ''
    admins = (config.get('ADMIN_IDS') or '633965399').strip()
    if not all(value.strip().isdigit() and int(value.strip()) > 0 for value in admins.split(',')):
        raise SystemExit('ADMIN_IDS должен содержать положительные числовые ID через запятую.')
    set_key(path, 'BOT_TOKEN', token)
    set_key(path, 'ADMIN_IDS', admins)
    if not config.get('DATABASE_PATH'):
        set_key(path, 'DATABASE_PATH', 'bot.db')
    if not config.get('WEB_PASSWORD_HASH'):
        print('\nПароль для сайта-админки (откроется на http://localhost:8080). Ввод скрыт.')
        while True:
            try:
                first = getpass('Новый пароль (не короче 10 символов): ')
                second = getpass('Повторите пароль: ')
            except (EOFError, KeyboardInterrupt):
                raise SystemExit('Настройка отменена.') from None
            if len(first) < 10:
                print('Пароль слишком короткий.')
            elif first != second:
                print('Пароли не совпали.')
            else:
                break
        set_key(path, 'WEB_PASSWORD_HASH', hash_password(first))
        set_key(path, 'WEB_ADMIN_USER', 'admin')
        print('Пароль сохранён. Логин: admin')
    print('Настройка готова. Ссылка чата: раздел «Чат участников», кнопка изменения ссылки.')


if __name__ == '__main__':
    main()
